# Imported Source Summary

- Public skill id: `monte-carlo-validation-notebook-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-awesome-skills/skills/monte-carlo-validation-notebook`
- Upstream support files copied: `2`

## Upstream File Preview

- `scripts/generate_notebook_url.py`
- `scripts/resolve_dbt_schema.py`
# Imported Source Summary

- Public skill id: `domain-identification-grouping`
- Source repository: `https://github.com/tech-leads-club/agent-skills`
- Source branch: `main`
- Source commit: `906a57d9bbfa69e6438f1baa17b31db95112fad7`
- Source skill path: `packages/skills-catalog/skills/(architecture)/domain-identification-grouping`
- Upstream support files copied: `2`

## Upstream File Preview

- `QUICK-REFERENCE.md`
- `README.md`
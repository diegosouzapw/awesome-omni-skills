# Imported Source Summary

- Public skill id: `similarity-search-patterns-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills/skills/similarity-search-patterns`
- Upstream support files copied: `1`

## Upstream File Preview

- `resources/implementation-playbook.md`
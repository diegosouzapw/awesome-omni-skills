# Imported Source Summary

- Public skill id: `obsidian-bases`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/obsidian-bases`
- Upstream support files copied: `1`

## Upstream File Preview

- `references/FUNCTIONS_REFERENCE.md`
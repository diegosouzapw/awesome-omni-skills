# Imported Source Summary

- Public skill id: `macos-spm-app-packaging`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/macos-spm-app-packaging`
- Upstream support files copied: `16`

## Upstream File Preview

- `agents/openai.yaml`
- `assets/templates/bootstrap/Package.swift`
- `assets/templates/bootstrap/Sources/MyApp/Resources/.keep`
- `assets/templates/bootstrap/Sources/MyApp/main.swift`
- `assets/templates/bootstrap/version.env`
- `assets/templates/build_icon.sh`
- `assets/templates/compile_and_run.sh`
- `assets/templates/launch.sh`
- `assets/templates/make_appcast.sh`
- `assets/templates/package_app.sh`
- `assets/templates/setup_dev_signing.sh`
- `assets/templates/sign-and-notarize.sh`
- `assets/templates/version.env`
- `references/packaging.md`
- `references/release.md`
- `references/scaffold.md`
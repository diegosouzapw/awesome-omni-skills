---
name: seo-keyword-strategist-v2
description: "seo-keyword-strategist workflow skill. Use this skill when the user needs Analyzes keyword usage in provided content, calculates density, suggests semantic variations and LSI keywords based on the topic. Prevents over-optimization. Use PROACTIVELY for content optimization and the operator should preserve the upstream workflow, copied support files, and provenance before merging or handing off."
version: "0.0.1"
category: tools
tags: ["seo-keyword-strategist-v2", "seo-keyword-strategist", "analyzes", "keyword", "usage", "provided", "content", "calculates"]
complexity: beginner
risk: safe
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "sickn33"
date_added: "2026-04-25"
date_updated: "2026-04-25"
---

# seo-keyword-strategist

## Overview

This public intake copy packages `plugins/antigravity-awesome-skills/skills/seo-keyword-strategist` from `https://github.com/sickn33/antigravity-awesome-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

This intake keeps the copied upstream files intact and uses the `external_source` block in `metadata.json` plus `ORIGIN.md` as the provenance anchor for review.

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: Focus Areas, Entity Analysis Framework, Approach, Output, Limitations.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- Working on seo keyword strategist tasks or workflows
- Needing guidance, best practices, or checklists for seo keyword strategist
- The task is unrelated to seo keyword strategist
- You need a different domain or tool outside this scope
- Use when provenance needs to stay visible in the answer, PR, or review packet.
- Use when copied upstream references, examples, or scripts materially improve the answer.

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `metadata.json` | Confirms repository, branch, commit, and imported path through the `external_source` block before touching the copied workflow |
| Provenance review | `ORIGIN.md` | Gives reviewers a plain-language audit trail for the imported source |
| Workflow execution | `SKILL.md` | Starts with the smallest copied file that materially changes execution |
| Supporting context | `SKILL.md` | Adds the next most relevant copied source file without loading the entire package |
| Handoff decision | `## Related Skills` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. Clarify goals, constraints, and required inputs.
2. Apply relevant best practices and validate outcomes.
3. Provide actionable steps and verification.
4. If detailed examples are required, open resources/implementation-playbook.md.
5. Confirm the user goal, the scope of the imported workflow, and whether this skill is still the right router for the task.
6. Read the overview and provenance files before loading any copied upstream support files.
7. Load only the references, examples, prompts, or scripts that materially change the outcome for the current request.

### Imported Workflow Notes

#### Imported: Instructions

- Clarify goals, constraints, and required inputs.
- Apply relevant best practices and validate outcomes.
- Provide actionable steps and verification.
- If detailed examples are required, open `resources/implementation-playbook.md`.

You are a keyword strategist analyzing content for semantic optimization opportunities.

#### Imported: Focus Areas

- Primary/secondary keyword identification
- Keyword density calculation and optimization
- Entity and topical relevance analysis
- LSI keyword generation from content
- Semantic variation suggestions
- Natural language patterns
- Over-optimization detection

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @seo-keyword-strategist-v2 to handle <task>. Start from the copied upstream workflow, load only the files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Ask for a provenance-grounded review

```text
Review @seo-keyword-strategist-v2 against metadata.json and ORIGIN.md, then explain which copied upstream files you would load first and why.
```

**Explanation:** Use this before review or troubleshooting when you need a precise, auditable explanation of origin and file selection.

### Example 3: Narrow the copied support files before execution

```text
Use @seo-keyword-strategist-v2 for <task>. Load only the copied references, examples, or scripts that change the outcome, and name the files explicitly before proceeding.
```

**Explanation:** This keeps the skill aligned with progressive disclosure instead of loading the whole copied package by default.

### Example 4: Build a reviewer packet

```text
Review @seo-keyword-strategist-v2 using the copied upstream files plus provenance, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.



## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The goal is to keep provenance explicit and load only the copied source material that materially improves execution.

- Primary keyword: 0.5-1.5% density
- Avoid keyword stuffing
- Natural placement throughout content
- Entity co-occurrence patterns
- Semantic variations for diversity
- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.
- Prefer the smallest useful set of support files so the workflow stays auditable and fast to review.

### Imported Operating Notes

#### Imported: Keyword Density Guidelines

**Best Practice Recommendations:**
- Primary keyword: 0.5-1.5% density
- Avoid keyword stuffing
- Natural placement throughout content
- Entity co-occurrence patterns
- Semantic variations for diversity

## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `plugins/antigravity-awesome-skills/skills/seo-keyword-strategist`, fails to mention provenance, or does not use any copied source files at all.
**Solution:** Re-open `metadata.json`, `ORIGIN.md`, and the most relevant copied upstream files. Check the `external_source` block first, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Point at the exact copied references, examples, scripts, or assets that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.



## Related Skills

- `@seo-fundamentals-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@seo-geo-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@seo-hreflang-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@seo-images-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operator packet for this imported skill. They should reflect real copied source material, not generic scaffolding.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | copied reference notes, guides, or background material from upstream | `references/n/a` |
| `examples` | worked examples or reusable prompts copied from upstream | `examples/n/a` |
| `scripts` | upstream helper scripts that change execution or validation | `scripts/n/a` |
| `agents` | routing or delegation notes that are genuinely part of the imported package | `agents/n/a` |
| `assets` | supporting assets or schemas copied from the source package | `assets/n/a` |



### Imported Reference Notes

#### Imported: Entity Analysis Framework

1. Identify primary entity relationships
2. Map related entities and concepts
3. Analyze competitor entity usage
4. Build topical authority signals
5. Create entity-rich content sections

#### Imported: Approach

1. Extract current keyword usage from provided content
2. Calculate keyword density percentages
3. Identify entities and related concepts in text
4. Determine likely search intent from content type
5. Generate LSI keywords based on topic
6. Suggest optimal keyword distribution
7. Flag over-optimization issues

#### Imported: Output

**Keyword Strategy Package:**
```
Primary: [keyword] (0.8% density, 12 uses)
Secondary: [keywords] (3-5 targets)
LSI Keywords: [20-30 semantic variations]
Entities: [related concepts to include]
```

**Deliverables:**
- Keyword density analysis
- Entity and concept mapping
- LSI keyword suggestions (20-30)
- Search intent assessment
- Content optimization checklist
- Keyword placement recommendations
- Over-optimization warnings

**Advanced Recommendations:**
- Question-based keywords for PAA
- Voice search optimization terms
- Featured snippet opportunities
- Keyword clustering for topic hubs

**Platform Integration:**
- WordPress: Integration with SEO plugins
- Static sites: Frontmatter keyword schema

Focus on natural keyword integration and semantic relevance. Build topical depth through related concepts.

#### Imported: Limitations

- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.

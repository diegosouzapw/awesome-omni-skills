# Origin for code-documentation-code-explain

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `846ac1c763877775967f0584ea06818e47aa0c2a`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/code-documentation-code-explain`
- Imported public skill id: `code-documentation-code-explain`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260424T184925.366726+0000-sickn33-antigravity-awesome-skills-weekly-forced`

The original source identity is preserved for review and attribution.

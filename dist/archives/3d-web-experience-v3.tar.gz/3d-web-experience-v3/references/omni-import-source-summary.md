# Imported Source Summary

- Public skill id: `3d-web-experience-v3`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-bundle-web-designer/skills/3d-web-experience`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
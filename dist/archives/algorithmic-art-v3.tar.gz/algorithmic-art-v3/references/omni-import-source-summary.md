# Imported Source Summary

- Public skill id: `algorithmic-art-v3`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-bundle-creative-director/skills/algorithmic-art`
- Upstream support files copied: `3`

## Upstream File Preview

- `LICENSE.txt`
- `templates/generator_template.js`
- `templates/viewer.html`
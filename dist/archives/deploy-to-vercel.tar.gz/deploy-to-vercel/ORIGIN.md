# Origin for deploy-to-vercel

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/vercel-labs/agent-skills.git`
- Source owner: `vercel-labs`
- Source repository name: `agent-skills`
- Source branch: `main`
- Source commit: `6f3fa3191d089d7810e332a562ad2a0ff5f7f239`
- Source skills path: `skills`
- Source skill path: `skills/deploy-to-vercel`
- Imported public skill id: `deploy-to-vercel`
- Source license: `UNKNOWN`
- License status: `review-required`
- Sync run id: `20260331T030837.056972+0000-vercel-labs-agent-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

# Origin for google-sheets-automation

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `99f4722632f1891e6b01d32d87b66e80b7ce0d07`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/google-sheets-automation`
- Imported public skill id: `google-sheets-automation`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260419T080807.522639+0000-sickn33-antigravity-awesome-skills-weekly`

The original source identity is preserved for review and attribution.

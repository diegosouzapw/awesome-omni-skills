# Attribution for android-ui-verification-v2

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `android-ui-verification-v2`
- Upstream title: `Android UI Verification Skill`
- Upstream path: `skills/android-ui-verification-v2/`
- Upstream author: `sickn33`
- Upstream source field: `community`
- Source PR: `#85`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `8fab9480d35a3f46aca4c7314a9d34bd60d77f92`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

# Origin for jira-assistant

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/tech-leads-club/agent-skills.git`
- Source owner: `tech-leads-club`
- Source repository name: `agent-skills`
- Source branch: `main`
- Source commit: `906a57d9bbfa69e6438f1baa17b31db95112fad7`
- Source skills path: `packages/skills-catalog/skills`
- Source skill path: `packages/skills-catalog/skills/(development)/jira-assistant`
- Imported public skill id: `jira-assistant`
- Source license: `MIT + CC-BY-4.0`
- License status: `review-required`
- Sync run id: `20260412T150925.447524+0000-tech-leads-club-agent-skills-dashboard-force-full-rescan`

The original source identity is preserved for review and attribution.

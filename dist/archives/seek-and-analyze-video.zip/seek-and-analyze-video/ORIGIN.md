# Origin for seek-and-analyze-video

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `9bad53f2426e310c33ef5bacf9f845855197be6a`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/seek-and-analyze-video`
- Imported public skill id: `seek-and-analyze-video`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260425T081806.659136+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

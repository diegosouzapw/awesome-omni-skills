# Attribution for dependency-management-deps-audit

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `dependency-management-deps-audit`
- Upstream title: `Dependency Audit and Security Analysis`
- Upstream path: `skills/dependency-management-deps-audit/`
- Upstream author: `sickn33`
- Upstream source field: `community`
- Source PR: `#271`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `93ab394af5645f7127d5003ee02c9566ae5353cd`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

# Origin for azure-appconfiguration-ts

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `1752c6c528af4684843870d16fbe0a90e785182b`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/azure-appconfiguration-ts`
- Imported public skill id: `azure-appconfiguration-ts`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260420T074419.699506+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

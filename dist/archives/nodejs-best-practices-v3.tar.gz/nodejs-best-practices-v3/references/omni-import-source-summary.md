# Imported Source Summary

- Public skill id: `nodejs-best-practices-v3`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-bundle-typescript-javascript/skills/nodejs-best-practices`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
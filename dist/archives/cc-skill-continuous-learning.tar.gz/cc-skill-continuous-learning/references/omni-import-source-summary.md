# Imported Source Summary

- Public skill id: `cc-skill-continuous-learning`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/cc-skill-continuous-learning`
- Upstream support files copied: `2`

## Upstream File Preview

- `config.json`
- `evaluate-session.sh`
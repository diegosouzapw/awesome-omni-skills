# Imported Source Summary

- Public skill id: `playwright-java-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills/skills/playwright-java`
- Upstream support files copied: `6`

## Upstream File Preview

- `BasePage.java`
- `BaseTest.java`
- `assertions.md`
- `config.md`
- `fixtures.md`
- `page-objects.md`
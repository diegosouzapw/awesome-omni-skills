# Imported Source Summary

- Public skill id: `playwright-skill-v4`
- Source repository: `https://github.com/tech-leads-club/agent-skills`
- Source branch: `main`
- Source commit: `906a57d9bbfa69e6438f1baa17b31db95112fad7`
- Source skill path: `packages/skills-catalog/skills/(web-automation)/playwright-skill`
- Upstream support files copied: `4`

## Upstream File Preview

- `API_REFERENCE.md`
- `lib/helpers.js`
- `package.json`
- `run.js`
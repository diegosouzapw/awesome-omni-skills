# Origin for azure-ai-contentsafety-java

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `3bb60df4ed7c14000fee689420266f7f5ed0a157`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/azure-ai-contentsafety-java`
- Imported public skill id: `azure-ai-contentsafety-java`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260416T050850.329799+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

# Attribution for wordpress-penetration-testing-v2

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `wordpress-penetration-testing-v2`
- Upstream title: `WordPress Penetration Testing`
- Upstream path: `skills/wordpress-penetration-testing-v2/`
- Upstream author: `zebbern`
- Upstream source field: `community`
- Source PR: `#245`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `59c910f364ee7d716890618a6eee877689b69af4`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

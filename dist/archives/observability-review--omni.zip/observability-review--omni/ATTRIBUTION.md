# Attribution for observability-review

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `observability-review`
- Upstream title: `Observability Review`
- Upstream path: `skills/observability-review/`
- Upstream author: `Omni Skills Team`
- Upstream source field: `omni-team`
- Source PR: `#0`
- Source PR author: `omni-skills-private`
- Source PR head repository: `diegosouzapw/omni-skills-private`
- Source PR head SHA: `baseline-sync`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

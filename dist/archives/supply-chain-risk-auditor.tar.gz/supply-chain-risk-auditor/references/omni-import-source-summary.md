# Imported Source Summary

- Public skill id: `supply-chain-risk-auditor`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/supply-chain-risk-auditor`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
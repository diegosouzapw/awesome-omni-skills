# Imported Source Summary

- Public skill id: `finishing-a-development-branch`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/finishing-a-development-branch`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
# Imported Source Summary

- Public skill id: `canvas-design-v3`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-bundle-creative-director/skills/canvas-design`
- Upstream support files copied: `82`

## Upstream File Preview

- `LICENSE.txt`
- `canvas-fonts/ArsenalSC-OFL.txt`
- `canvas-fonts/ArsenalSC-Regular.ttf`
- `canvas-fonts/BigShoulders-Bold.ttf`
- `canvas-fonts/BigShoulders-OFL.txt`
- `canvas-fonts/BigShoulders-Regular.ttf`
- `canvas-fonts/Boldonse-OFL.txt`
- `canvas-fonts/Boldonse-Regular.ttf`
- `canvas-fonts/BricolageGrotesque-Bold.ttf`
- `canvas-fonts/BricolageGrotesque-OFL.txt`
- `canvas-fonts/BricolageGrotesque-Regular.ttf`
- `canvas-fonts/CrimsonPro-Bold.ttf`
- `canvas-fonts/CrimsonPro-Italic.ttf`
- `canvas-fonts/CrimsonPro-OFL.txt`
- `canvas-fonts/CrimsonPro-Regular.ttf`
- `canvas-fonts/DMMono-OFL.txt`
- `canvas-fonts/DMMono-Regular.ttf`
- `canvas-fonts/EricaOne-OFL.txt`
- `canvas-fonts/EricaOne-Regular.ttf`
- `canvas-fonts/GeistMono-Bold.ttf`
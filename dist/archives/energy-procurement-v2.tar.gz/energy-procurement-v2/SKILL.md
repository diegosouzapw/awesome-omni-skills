---
name: energy-procurement-v2
description: "Energy Procurement workflow skill. Use this skill when the user needs Codified expertise for electricity and gas procurement, tariff optimisation, demand charge management, renewable PPA evaluation, and multi-facility energy cost management and the operator should rely on the packaged workflow, support pack, troubleshooting notes, and provenance links before merging or handing off."
version: "0.0.1"
category: business
tags: ["energy-procurement-v2", "energy-procurement", "codified", "expertise", "for", "electricity", "and", "gas"]
complexity: advanced
risk: caution
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "sickn33"
date_added: "2026-04-12"
date_updated: "2026-04-12"
---

# Energy Procurement

## Overview

This public intake copy packages `plugins/antigravity-awesome-skills/skills/energy-procurement` from `https://github.com/sickn33/antigravity-awesome-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

The packaged support pack adds a checklist, rubric, playbook, prompt template, router note, and source manifest so reviewers can audit the import as a complete workflow kit instead of a raw file dump.

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: Role and Context, Core Knowledge, Decision Frameworks, Key Edge Cases, Communication Patterns, Escalation Protocols.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- Evaluating fixed vs. index vs. block-and-index contracts, PPAs, or VPPAs.
- Reducing demand charges, managing capacity tags, or planning DR and battery investments.
- Preparing RFPs, supplier negotiations, or executive decision memos about multi-site energy strategy, risk, and sustainability tradeoffs.
- Use when provenance needs to stay visible in the answer, PR, or review packet.
- Use when the support pack, checklist, rubric, and playbook should guide execution before touching code or tools.
- Use when the workflow should remain reviewable in the public intake repo before the private enhancer takes over.

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `references/omni-import-playbook.md` | Establishes the workflow, review packet, and provenance expectations before work begins |
| PR review or merge readiness | `references/omni-import-rubric.md` | Turns the imported skill into a checklist-driven review packet instead of an opaque file copy |
| Source or lineage verification | `scripts/omni_import_print_origin.py` | Confirms repository, branch, commit, and imported path quickly |
| Workflow execution | `references/omni-import-checklist.md` | Gives the operator the smallest useful entry point into the support pack |
| Handoff decision | `agents/omni-import-router.md` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. Confirm the user goal, the scope of the imported workflow, and whether this skill is still the right router for the task.
2. Read the overview, playbook, and source summary before loading any upstream support files.
3. Load only the references, examples, prompts, or scripts that materially change the outcome for the current request.
4. Execute the upstream workflow while keeping provenance and source boundaries explicit in the working notes.
5. Validate the result against the checklist, rubric, and expected evidence for the task.
6. Escalate or hand off to a related skill when the work moves out of this imported workflow's center of gravity.
7. Before merge or closure, record what was used, what changed, and what the reviewer still needs to verify.

### Imported Workflow Notes

#### Imported: Role and Context

You are a senior energy procurement manager at a large commercial and industrial (C&I) consumer with multiple facilities across regulated and deregulated electricity markets. You manage an annual energy spend of $15M–$80M across 10–50+ sites — manufacturing plants, distribution centers, corporate offices, and cold storage. You own the full procurement lifecycle: tariff analysis, supplier RFPs, contract negotiation, demand charge management, renewable energy sourcing, budget forecasting, and sustainability reporting. You sit between operations (who control load), finance (who own the budget), sustainability (who set emissions targets), and executive leadership (who approve long-term commitments like PPAs). Your systems include utility bill management platforms (Urjanet, EnergyCAP), interval data analytics (meter-level 15-minute kWh/kW), energy market data providers (ICE, CME, Platts), and procurement platforms (energy brokers, aggregators, direct ISO market access). You balance cost reduction against budget certainty, sustainability targets, and operational flexibility — because a procurement strategy that saves 8% but exposes the company to a $2M budget variance in a polar vortex year is not a good strategy.

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @energy-procurement-v2 to handle <task>. Start with the workflow playbook, load only the upstream files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Inspect origin and import state

```bash
python3 skills/energy-procurement-v2/scripts/omni_import_print_origin.py
```

**Explanation:** Use this before review or troubleshooting when you need to confirm source repository, branch, commit, and path.

### Example 3: Review the support pack before execution

```bash
python3 skills/energy-procurement-v2/scripts/omni_import_list_support_pack.py
```

**Explanation:** This gives the operator a quick inventory of the imported references, examples, scripts, router notes, and manifest files.

### Example 4: Build a reviewer packet

```text
Review @energy-procurement-v2 using the checklist, rubric, playbook, and source manifest, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.



## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The checklist, rubric, worksheet, template, and playbook are there to make the import auditable, not to hide the source material.

- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.
- Prefer the smallest useful set of support files so the workflow stays auditable and fast to review.
- Keep provenance, source commit, and imported file paths visible in notes and PR descriptions.
- Use the checklist, rubric, worksheet, and playbook together instead of relying on a single section in isolation.
- Treat generated examples as scaffolding; adapt them to the concrete task before execution.
- Route to a stronger native skill when architecture, debugging, design, or security concerns become dominant.



## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `plugins/antigravity-awesome-skills/skills/energy-procurement`, fails to mention provenance, or does not use the support pack at all.
**Solution:** Re-open the checklist, playbook, source summary, and source manifest. Load only the upstream files that materially change the answer, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Use the operator packet and support-pack listing to point at the exact references, examples, scripts, and router notes that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the router note and related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.



## Related Skills

- `@00-andruia-consultant` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@00-andruia-consultant-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operational packet for this imported skill. Together they provide the checklist, rubric, template, playbook, router guidance, and manifest that the validator expects to see represented in the public skill.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | checklists, rubrics, playbooks, and source summaries | `references/communication-templates.md` |
| `examples` | prompt packets and usage templates | `examples/omni-import-operator-packet.md` |
| `scripts` | origin inspection and support-pack listing | `scripts/omni_import_list_support_pack.py` |
| `agents` | routing and handoff guidance | `agents/omni-import-router.md` |
| `assets` | machine-readable source manifest | `assets/omni-import-source-manifest.json` |

- [Imported intake checklist](references/omni-import-checklist.md)
- [Imported review rubric](references/omni-import-rubric.md)
- [Imported workflow playbook](references/omni-import-playbook.md)
- [Imported source summary](references/omni-import-source-summary.md)
- [Imported operator packet](examples/omni-import-operator-packet.md)
- [Imported prompt template](examples/omni-import-prompt-template.md)
- [Print origin details](scripts/omni_import_print_origin.py)
- [List support pack](scripts/omni_import_list_support_pack.py)

### Imported Reference Notes

#### Imported: Additional Resources

- For detailed decision frameworks on procurement strategy, PPA evaluation, hedging, and multi-facility optimization, see [decision-frameworks.md](references/decision-frameworks.md)
- For the comprehensive edge case library with full analysis, see [edge-cases.md](references/edge-cases.md)
- For communication templates covering RFPs, PPA negotiations, rate cases, and internal reporting, see [communication-templates.md](references/communication-templates.md)

#### Imported: Core Knowledge

### Pricing Structures and Utility Bill Anatomy

Every commercial electricity bill has components that must be understood independently — bundling them into a single "rate" obscures where real optimization opportunities exist:

- **Energy charges:** The per-kWh cost for electricity consumed. Can be flat rate (same price all hours), time-of-use/TOU (different prices for on-peak, mid-peak, off-peak), or real-time pricing/RTP (hourly prices indexed to wholesale market). For large C&I customers, energy charges typically represent 40–55% of the total bill. In deregulated markets, this is the component you can competitively procure.
- **Demand charges:** Billed on peak kW drawn during a billing period, measured in 15-minute intervals. The utility takes the highest single 15-minute average kW reading in the month and multiplies by the demand rate ($8–$25/kW depending on utility and rate class). Demand charges represent 20–40% of the bill for manufacturing facilities with variable loads. One bad 15-minute interval — a compressor startup coinciding with HVAC peak — can add $5,000–$15,000 to a monthly bill.
- **Capacity charges:** In markets with capacity obligations (PJM, ISO-NE, NYISO), your share of the grid's capacity cost is allocated based on your peak load contribution (PLC) during the prior year's system peak hours (typically 1–5 hours in summer). PLC is measured at your meter during the system coincident peak. Reducing load during those few critical hours can cut capacity charges by 15–30% the following year. This is the single highest-ROI demand response opportunity for most C&I customers.
- **Transmission and distribution (T&D):** Regulated charges for moving power from generation to your meter. Transmission is typically based on your contribution to the regional transmission peak (similar to capacity). Distribution includes customer charges, demand-based delivery charges, and volumetric delivery charges. These are generally non-bypassable — even with on-site generation, you pay distribution charges for being connected to the grid.
- **Riders and surcharges:** Renewable energy standards compliance, nuclear decommissioning, utility transition charges, and regulatory mandated programs. These change through rate cases. A utility rate case filing can add $0.005–$0.015/kWh to your delivered cost — track open proceedings at your state PUC.

### Procurement Strategies

The core decision in deregulated markets is how much price risk to retain versus transfer to suppliers:

- **Fixed-price (full requirements):** Supplier provides all electricity at a locked $/kWh for the contract term (12–36 months). Provides budget certainty. You pay a risk premium — typically 5–12% above the forward curve at contract signing — because the supplier is absorbing price, volume, and basis risk. Best for organizations where budget predictability outweighs cost minimization.
- **Index/variable pricing:** You pay the real-time or day-ahead wholesale price plus a supplier adder ($0.002–$0.006/kWh). Lowest long-run average cost, but full exposure to price spikes. In ERCOT during Winter Storm Uri (Feb 2021), wholesale prices hit $9,000/MWh — an index customer on a 5 MW peak load faced a single-week energy bill exceeding $1.5M. Index pricing requires active risk management and a corporate culture that tolerates budget variance.
- **Block-and-index (hybrid):** You purchase fixed-price blocks to cover your baseload (60–80% of expected consumption) and let the remaining variable load float at index. This balances cost optimization with partial budget certainty. The blocks should match your base load shape — if your facility runs 3 MW baseload 24/7 with a 2 MW variable load during production hours, buy 3 MW blocks around-the-clock and 2 MW blocks on-peak only.
- **Layered procurement:** Instead of locking in your full load at one point in time (which concentrates market timing risk), buy in tranches over 12–24 months. For example, for a 2027 contract year: buy 25% in Q1 2025, 25% in Q3 2025, 25% in Q1 2026, and the remaining 25% in Q3 2026. Dollar-cost averaging for energy. This is the single most effective risk management technique available to most C&I buyers — it eliminates the "did we lock at the top?" problem.
- **RFP process in deregulated markets:** Issue RFPs to 5–8 qualified retail energy providers (REPs). Include 36 months of interval data, your load factor, site addresses, utility account numbers, current contract expiration dates, and any sustainability requirements (RECs, carbon-free targets). Evaluate on total cost, supplier credit quality (check S&P/Moody's — a supplier bankruptcy mid-contract forces you into utility default service at tariff rates), contract flexibility (change-of-use provisions, early termination), and value-added services (demand response management, sustainability reporting, market intelligence).

### Demand Charge Management

Demand charges are the most controllable cost component for facilities with operational flexibility:

- **Peak identification:** Download 15-minute interval data from your utility or meter data management system. Identify the top 10 peak intervals per month. In most facilities, 6–8 of the top 10 peaks share a common root cause — simultaneous startup of multiple large loads (chillers, compressors, production lines) during morning ramp-up between 6:00–9:00 AM.
- **Load shifting:** Move discretionary loads (batch processes, charging, thermal storage, water heating) to off-peak periods. A 500 kW load shifted from on-peak to off-peak saves $5,000–$12,500/month in demand charges alone, plus energy cost differential.
- **Peak shaving with batteries:** Behind-the-meter battery storage can cap peak demand by discharging during the highest-demand 15-minute intervals. A 500 kW / 2 MWh battery system costs $800K–$1.2M installed. At $15/kW demand charge, shaving 500 kW saves $7,500/month ($90K/year). Simple payback: 9–13 years — but stack demand charge savings with TOU energy arbitrage, capacity tag reduction, and demand response program payments, and payback drops to 5–7 years.
- **Demand response (DR) programs:** Utility and ISO-operated programs pay customers to curtail load during grid stress events. PJM's Economic DR program pays the LMP for curtailed load during high-price hours. ERCOT's Emergency Response Service (ERS) pays a standby fee plus an energy payment during events. DR revenue for a 1 MW curtailment capability: $15K–$80K/year depending on market, program, and number of dispatch events.
- **Ratchet clauses:** Many tariffs include a demand ratchet — your billed demand cannot fall below 60–80% of the highest peak demand recorded in the prior 11 months. A single accidental peak of 6 MW when your normal peak is 4 MW locks you into billing demand of at least 3.6–4.8 MW for a year. Always check your tariff for ratchet provisions before any facility modification that could spike peak load.

### Renewable Energy Procurement

- **Physical PPA:** You contract directly with a renewable generator (solar/wind farm) to purchase output at a fixed $/MWh price for 10–25 years. The generator is typically located in the same ISO where your load is, and power flows through the grid to your meter. You receive both the energy and the associated RECs. Physical PPAs require you to manage basis risk (the price difference between the generator's node and your load zone), curtailment risk (when the ISO curtails the generator), and shape risk (solar produces when the sun shines, not when you consume).
- **Virtual (financial) PPA (VPPA):** A contract-for-differences. You agree on a fixed strike price (e.g., $35/MWh). The generator sells power into the wholesale market at the settlement point price. If the market price is $45/MWh, the generator pays you $10/MWh. If the market price is $25/MWh, you pay the generator $10/MWh. You receive RECs to claim renewable attributes. VPPAs do not change your physical power supply — you continue buying from your retail supplier. VPPAs are financial instruments and may require CFO/treasury approval, ISDA agreements, and mark-to-market accounting treatment.
- **RECs (Renewable Energy Certificates):** 1 REC = 1 MWh of renewable generation attributes. Unbundled RECs (purchased separately from physical power) are the cheapest way to claim renewable energy use — $1–$5/MWh for national wind RECs, $5–$15/MWh for solar RECs, $20–$60/MWh for specific regional markets (New England, PJM). However, unbundled RECs face increasing scrutiny under GHG Protocol Scope 2 guidance: they satisfy market-based accounting but do not demonstrate "additionality" (causing new renewable generation to be built).
- **On-site generation:** Rooftop or ground-mount solar, combined heat and power (CHP). On-site solar PPA pricing: $0.04–$0.08/kWh depending on location, system size, and ITC eligibility. On-site generation reduces T&D exposure and can lower capacity tags. But behind-the-meter generation introduces net metering risk (utility compensation rate changes), interconnection costs, and site lease complications. Evaluate on-site vs. off-site based on total economic value, not just energy cost.

### Load Profiling

Understanding your facility's load shape is the foundation of every procurement and optimization decision:

- **Base vs. variable load:** Base load runs 24/7 — process refrigeration, server rooms, continuous manufacturing, lighting in occupied areas. Variable load correlates with production schedules, occupancy, and weather (HVAC). A facility with a 0.85 load factor (base load is 85% of peak) benefits from around-the-clock block purchases. A facility with a 0.45 load factor (large swings between occupied and unoccupied) benefits from shaped products that match the on-peak/off-peak pattern.
- **Load factor:** Average demand divided by peak demand. Load factor = (Total kWh) / (Peak kW × Hours in period). A high load factor (>0.75) means relatively flat, predictable consumption — easier to procure and lower demand charges per kWh. A low load factor (<0.50) means spiky consumption with a high peak-to-average ratio — demand charges dominate your bill and peak shaving has the highest ROI.
- **Contribution by system:** In manufacturing, typical load breakdown: HVAC 25–35%, production motors/drives 30–45%, compressed air 10–15%, lighting 5–10%, process heating 5–15%. The system contributing most to peak demand is not always the one consuming the most energy — compressed air systems often have the worst peak-to-average ratio due to unloaded running and cycling compressors.

### Market Structures

- **Regulated markets:** A single utility provides generation, transmission, and distribution. Rates are set by the state Public Utility Commission (PUC) through periodic rate cases. You cannot choose your electricity supplier. Optimization is limited to tariff selection (switching between available rate schedules), demand charge management, and on-site generation. Approximately 35% of US commercial electricity load is in fully regulated markets.
- **Deregulated markets:** Generation is competitive. You can buy electricity from qualified retail energy providers (REPs), directly from the wholesale market (if you have the infrastructure and credit), or through brokers/aggregators. ISOs/RTOs operate the wholesale market: PJM (Mid-Atlantic and Midwest, largest US market), ERCOT (Texas, uniquely isolated grid), CAISO (California), NYISO (New York), ISO-NE (New England), MISO (Central US), SPP (Plains states). Each ISO has different market rules, capacity structures, and pricing mechanisms.
- **Locational Marginal Pricing (LMP):** Wholesale electricity prices vary by location (node) within an ISO, reflecting generation costs, transmission losses, and congestion. LMP = Energy Component + Congestion Component + Loss Component. A facility at a congested node pays more than one at an uncongested node. Congestion can add $5–$30/MWh to your delivered cost in constrained zones. When evaluating a VPPA, the basis risk between the generator's node and your load zone is driven by congestion patterns.

### Sustainability Reporting

- **Scope 2 emissions — two methods:** The GHG Protocol requires dual reporting. Location-based: uses average grid emission factor for your region (eGRID in the US). Market-based: reflects your procurement choices — if you buy RECs or have a PPA, your market-based emissions decrease. Most companies targeting RE100 or SBTi approval focus on market-based Scope 2.
- **RE100:** A global initiative where companies commit to 100% renewable electricity. Requires annual reporting of progress. Acceptable instruments: physical PPAs, VPPAs with RECs, utility green tariff programs, unbundled RECs (though RE100 is tightening additionality requirements), and on-site generation.
- **CDP and SBTi:** CDP (formerly Carbon Disclosure Project) scores corporate climate disclosure. Energy procurement data feeds your CDP Climate Change questionnaire directly — Section C8 (Energy). SBTi (Science Based Targets initiative) validates that your emissions reduction targets align with Paris Agreement goals. Procurement decisions that lock in fossil-heavy supply for 10+ years can conflict with SBTi trajectories.

### Risk Management

- **Hedging approaches:** Layered procurement is the primary hedge. Supplement with financial hedges (swaps, options, heat rate call options) for specific exposures. Buy put options on wholesale electricity to cap your index pricing exposure — a $50/MWh put costs $2–$5/MWh premium but prevents the catastrophic tail risk of $200+/MWh wholesale spikes.
- **Budget certainty vs. market exposure:** The fundamental tradeoff. Fixed-price contracts provide certainty at a premium. Index contracts provide lower average cost at higher variance. Most sophisticated C&I buyers land on 60–80% hedged, 20–40% index — the exact ratio depends on the company's financial profile, treasury risk tolerance, and whether energy is a material input cost (manufacturers) or an overhead line item (offices).
- **Weather risk:** Heating degree days (HDD) and cooling degree days (CDD) drive consumption variance. A winter 15% colder than normal can increase natural gas costs 25–40% above budget. Weather derivatives (HDD/CDD swaps and options) can hedge volumetric risk — but most C&I buyers manage weather risk through budget reserves rather than financial instruments.
- **Regulatory risk:** Tariff changes through rate cases, capacity market reform (PJM's capacity market has restructured pricing 3 times since 2015), carbon pricing legislation, and net metering policy changes can all shift the economics of your procurement strategy mid-contract.

#### Imported: Decision Frameworks

### Procurement Strategy Selection

When choosing between fixed, index, and block-and-index for a contract renewal:

1. **What is the company's tolerance for budget variance?** If energy cost variance >5% of budget triggers a management review, lean fixed. If the company can absorb 15–20% variance without financial stress, index or block-and-index is viable.
2. **Where is the market in the price cycle?** If forward curves are at the bottom third of the 5-year range, lock in more fixed (buy the dip). If forwards are at the top third, keep more index exposure (don't lock at the peak). If uncertain, layer.
3. **What is the contract tenor?** For 12-month terms, fixed vs. index matters less — the premium is small and the exposure period is short. For 36+ month terms, the risk premium on fixed pricing compounds and the probability of overpaying increases. Lean hybrid or layered for longer tenors.
4. **What is the facility's load factor?** High load factor (>0.75): block-and-index works well — buy flat blocks around the clock. Low load factor (<0.50): shaped blocks or TOU-indexed products better match the load profile.

### PPA Evaluation

Before committing to a 10–25 year PPA, evaluate:

1. **Does the project economics pencil?** Compare the PPA strike price to the forward curve for the contract tenor. A $35/MWh solar PPA against a $45/MWh forward curve has $10/MWh positive spread. But model the full term — a 20-year PPA at $35/MWh that was in-the-money at signing can go underwater if wholesale prices drop below the strike due to overbuilding of renewables in the region.
2. **What is the basis risk?** If the generator is in West Texas (ERCOT West) and your load is in Houston (ERCOT Houston), congestion between the two zones can create a persistent basis spread of $3–$12/MWh that erodes the PPA value. Require the developer to provide 5+ years of historical basis data between the project node and your load zone.
3. **What is the curtailment exposure?** ERCOT curtails wind at 3–8% annually; CAISO curtails solar at 5–12% in spring months. If the PPA settles on generated (not scheduled) volumes, curtailment reduces your REC delivery and changes the economics. Negotiate a curtailment cap or a settlement structure that doesn't penalize you for grid-operator curtailment.
4. **What are the credit requirements?** Developers typically require investment-grade credit or a letter of credit / parent guarantee for long-term PPAs. A $50M notional VPPA may require a $5–$10M LC, tying up capital. Factor the LC cost into your PPA economics.

### Demand Charge Mitigation ROI

Evaluate demand charge reduction investments using total stacked value:

1. Calculate current demand charges: Peak kW × demand rate × 12 months.
2. Estimate achievable peak reduction from the proposed intervention (battery, load control, DR).
3. Value the reduction across all applicable tariff components: demand charges + capacity tag reduction (takes effect following delivery year) + TOU energy arbitrage + DR program revenue.
4. If simple payback < 5 years with stacked value, the investment is typically justified. If 5–8 years, it's marginal and depends on capital availability. If > 8 years on stacked value, the economics don't work unless driven by sustainability mandate.

### Market Timing

Never try to "call the bottom" on energy markets. Instead:

- Monitor the forward curve relative to the 5-year historical range. When forwards are in the bottom quartile, accelerate procurement (buy tranches faster than your layering schedule). When in the top quartile, decelerate (let existing tranches roll and increase index exposure).
- Watch for structural signals: new generation additions (bearish for prices), plant retirements (bullish), pipeline constraints for natural gas (regional price divergence), and capacity market auction results (drives future capacity charges).

For the complete decision framework library, see [decision-frameworks.md](references/decision-frameworks.md).

#### Imported: Key Edge Cases

These are situations where standard procurement playbooks produce poor outcomes. Brief summaries here — see [edge-cases.md](references/edge-cases.md) for full analysis.

1. **ERCOT price spike during extreme weather:** Winter Storm Uri demonstrated that index-priced customers in ERCOT face catastrophic tail risk. A 5 MW facility on index pricing incurred $1.5M+ in a single week. The lesson is not "avoid index pricing" — it's "never go unhedged into winter in ERCOT without a price cap or financial hedge."

2. **Virtual PPA basis risk in a congested zone:** A VPPA with a wind farm in West Texas settling against Houston load zone prices can produce persistent negative settlements of $3–$12/MWh due to transmission congestion, turning an apparently favorable PPA into a net cost.

3. **Demand charge ratchet trap:** A facility modification (new production line, chiller replacement startup) creates a single month's peak 50% above normal. The tariff's 80% ratchet clause locks elevated billing demand for 11 months. A $200K annual cost increase from a single 15-minute interval.

4. **Utility rate case filing mid-contract:** Your fixed-price supply contract covers the energy component, but T&D and rider charges flow through. A utility rate case adds $0.012/kWh to delivery charges — a $150K annual increase on a 12 MW facility that your "fixed" contract doesn't protect against.

5. **Negative LMP pricing affecting PPA economics:** During high-wind or high-solar periods, wholesale prices go negative at the generator's node. Under some PPA structures, you owe the developer the settlement difference on negative-price intervals, creating surprise payments.

6. **Behind-the-meter solar cannibalizing demand response value:** On-site solar reduces your average consumption but may not reduce your peak (peaks often occur on cloudy late afternoons). If your DR baseline is calculated on recent consumption, solar reduces the baseline, which reduces your DR curtailment capacity and associated revenue.

7. **Capacity market obligation surprise:** In PJM, your capacity tag (PLC) is set by your load during the prior year's 5 coincident peak hours. If you ran backup generators or increased production during a heat wave that happened to include peak hours, your PLC spikes, and capacity charges increase 20–40% the following delivery year.

8. **Deregulated market re-regulation risk:** A state legislature proposes re-regulation after a price spike event. If enacted, your competitively procured supply contract may be voided, and you revert to utility tariff rates — potentially at higher cost than your negotiated contract.

#### Imported: Communication Patterns

### Supplier Negotiations

Energy supplier negotiations are multi-year relationships. Calibrate tone:

- **RFP issuance:** Professional, data-rich, competitive. Provide complete interval data and load profiles. Suppliers who can't model your load accurately will pad their margins. Transparency reduces risk premiums.
- **Contract renewal:** Lead with relationship value and volume growth, not price demands. "We've valued the partnership over the past 36 months and want to discuss renewal terms that reflect both market conditions and our growing portfolio."
- **Price challenges:** Reference specific market data. "ICE forward curves for 2027 are showing $42/MWh for AEP Dayton Hub. Your quote of $48/MWh reflects a 14% premium to the curve — can you help us understand what's driving that spread?"

### Internal Stakeholders

- **Finance/treasury:** Quantify decisions in terms of budget impact, variance, and risk. "This block-and-index structure provides 75% budget certainty with a modeled worst-case variance of ±$400K against a $12M annual energy budget."
- **Sustainability:** Map procurement decisions to Scope 2 targets. "This PPA delivers 50,000 MWh of bundled RECs annually, representing 35% of our RE100 target."
- **Operations:** Focus on operational requirements and constraints. "We need to reduce peak demand by 400 kW during summer afternoons — here are three options that don't affect production schedules."

For full communication templates, see [communication-templates.md](references/communication-templates.md).

#### Imported: Escalation Protocols

| Trigger                                                              | Action                                                                                      | Timeline               |
| -------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ---------------------- |
| Wholesale prices exceed 2× budget assumption for 5+ consecutive days | Notify finance, evaluate hedge position, consider emergency fixed-price procurement         | Within 24 hours        |
| Supplier credit downgrade below investment grade                     | Review contract termination provisions, assess replacement supplier options                 | Within 48 hours        |
| Utility rate case filed with >10% proposed increase                  | Engage regulatory counsel, evaluate intervention filing                                     | Within 1 week          |
| Demand peak exceeds ratchet threshold by >15%                        | Investigate root cause with operations, model billing impact, evaluate mitigation           | Within 24 hours        |
| PPA developer misses REC delivery by >10% of contracted volume       | Issue notice of default per contract, evaluate replacement REC procurement                  | Within 5 business days |
| Capacity tag (PLC) increases >20% from prior year                    | Analyze coincident peak intervals, model capacity charge impact, develop peak response plan | Within 2 weeks         |
| Regulatory action threatens contract enforceability                  | Engage legal counsel, evaluate contract force majeure provisions                            | Within 48 hours        |
| Grid emergency / rolling blackouts affecting facilities              | Activate emergency load curtailment, coordinate with operations, document for insurance     | Immediate              |

### Escalation Chain

Energy Analyst → Energy Procurement Manager (24 hours) → Director of Procurement (48 hours) → VP Finance/CFO (>$500K exposure or long-term commitment >5 years)

#### Imported: Performance Indicators

Track monthly, review quarterly with finance and sustainability:

| Metric                                                                     | Target                        | Red Flag               |
| -------------------------------------------------------------------------- | ----------------------------- | ---------------------- |
| Weighted average energy cost vs. budget                                    | Within ±5%                    | >10% variance          |
| Procurement cost vs. market benchmark (forward curve at time of execution) | Within 3% of market           | >8% premium            |
| Demand charges as % of total bill                                          | <25% (manufacturing)          | >35%                   |
| Peak demand vs. prior year (weather-normalized)                            | Flat or declining             | >10% increase          |
| Renewable energy % (market-based Scope 2)                                  | On track to RE100 target year | >15% behind trajectory |
| Supplier contract renewal lead time                                        | Signed ≥90 days before expiry | <30 days before expiry |
| Capacity tag (PLC/ICAP) trend                                              | Flat or declining             | >15% YoY increase      |
| Budget forecast accuracy (Q1 forecast vs. actuals)                         | Within ±7%                    | >12% miss              |

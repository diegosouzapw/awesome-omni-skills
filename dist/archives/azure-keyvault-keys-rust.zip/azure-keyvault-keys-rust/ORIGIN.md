# Origin for azure-keyvault-keys-rust

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `bf2a00a954ca84cbabe4f712264eec5dac21b1cf`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/azure-keyvault-keys-rust`
- Imported public skill id: `azure-keyvault-keys-rust`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260419T070221.954117+0000-sickn33-antigravity-awesome-skills-weekly`

The original source identity is preserved for review and attribution.

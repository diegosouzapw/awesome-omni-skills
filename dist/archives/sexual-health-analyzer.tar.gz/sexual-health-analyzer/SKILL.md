---
name: sexual-health-analyzer
description: "\u6027\u5065\u5eb7\u5206\u6790\u6280\u80fd workflow skill. Use this skill when the user needs Sexual Health Analyzer and the operator should preserve the upstream workflow, copied support files, and provenance before merging or handing off."
version: "0.0.1"
category: uncategorized
tags: ["sexual-health-analyzer", "sexual", "health", "analyzer", "uncategorized"]
complexity: advanced
risk: safe
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "sickn33"
date_added: "2026-04-15"
date_updated: "2026-04-18"
---

# 性健康分析技能

## Overview

This public intake copy packages `plugins/antigravity-awesome-skills-claude/skills/sexual-health-analyzer` from `https://github.com/sickn33/antigravity-awesome-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

This intake keeps the copied upstream files intact and uses `metadata.json` plus `ORIGIN.md` as the provenance anchor for review.

# 性健康分析技能

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: 技能概述, 医学免责声明, 核心功能, 使用场景, 数据分析方法, 质量保证.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- 需要分析性健康记录、筛查情况、避孕效果或相关风险模式时使用。
- 任务涉及 IIEF-5 评分、STD 筛查管理、性活动统计或跨模块关联分析。
- 用户请求性健康趋势报告或结构化风险分析时使用。
- Use when the request clearly matches the imported source intent: Sexual Health Analyzer.
- Use when the operator should preserve upstream workflow detail instead of rewriting the process from scratch.
- Use when provenance needs to stay visible in the answer, PR, or review packet.

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `metadata.json` | Confirms repository, branch, commit, and imported path before touching the copied workflow |
| Provenance review | `ORIGIN.md` | Gives reviewers a plain-language audit trail for the imported source |
| Workflow execution | `SKILL.md` | Starts with the smallest copied file that materially changes execution |
| Supporting context | `SKILL.md` | Adds the next most relevant copied source file without loading the entire package |
| Handoff decision | `## Related Skills` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. Confirm the user goal, the scope of the imported workflow, and whether this skill is still the right router for the task.
2. Read the overview and provenance files before loading any copied upstream support files.
3. Load only the references, examples, prompts, or scripts that materially change the outcome for the current request.
4. Execute the upstream workflow while keeping provenance and source boundaries explicit in the working notes.
5. Validate the result against the upstream expectations and the evidence you can point to in the copied files.
6. Escalate or hand off to a related skill when the work moves out of this imported workflow's center of gravity.
7. Before merge or closure, record what was used, what changed, and what the reviewer still needs to verify.

### Imported Workflow Notes

#### Imported: 技能概述

本技能提供全面的性健康数据分析功能,包括IIEF-5评分分析、STD筛查管理、避孕效果评估、性活动统计以及与用药、慢性病、心理、营养、运动等模块的深度关联分析。

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @sexual-health-analyzer to handle <task>. Start from the copied upstream workflow, load only the files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Ask for a provenance-grounded review

```text
Review @sexual-health-analyzer against metadata.json and ORIGIN.md, then explain which copied upstream files you would load first and why.
```

**Explanation:** Use this before review or troubleshooting when you need a precise, auditable explanation of origin and file selection.

### Example 3: Narrow the copied support files before execution

```text
Use @sexual-health-analyzer for <task>. Load only the copied references, examples, or scripts that change the outcome, and name the files explicitly before proceeding.
```

**Explanation:** This keeps the skill aligned with progressive disclosure instead of loading the whole copied package by default.

### Example 4: Build a reviewer packet

```text
Review @sexual-health-analyzer using the copied upstream files plus provenance, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.



## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The goal is to keep provenance explicit and load only the copied source material that materially improves execution.

- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.
- Prefer the smallest useful set of support files so the workflow stays auditable and fast to review.
- Keep provenance, source commit, and imported file paths visible in notes and PR descriptions.
- Point directly at the copied upstream files that justify the workflow instead of relying on generic review boilerplate.
- Treat generated examples as scaffolding; adapt them to the concrete task before execution.
- Route to a stronger native skill when architecture, debugging, design, or security concerns become dominant.



## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `plugins/antigravity-awesome-skills-claude/skills/sexual-health-analyzer`, fails to mention provenance, or does not use any copied source files at all.
**Solution:** Re-open `metadata.json`, `ORIGIN.md`, and the most relevant copied upstream files. Load only the files that materially change the answer, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Point at the exact copied references, examples, scripts, or assets that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.



## Related Skills

- `@server-management` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@service-mesh-expert` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@service-mesh-observability` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@shadcn` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operator packet for this imported skill. They should reflect real copied source material, not generic scaffolding.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | copied reference notes, guides, or background material from upstream | `references/n/a` |
| `examples` | worked examples or reusable prompts copied from upstream | `examples/n/a` |
| `scripts` | upstream helper scripts that change execution or validation | `scripts/n/a` |
| `agents` | routing or delegation notes that are genuinely part of the imported package | `agents/n/a` |
| `assets` | supporting assets or schemas copied from the source package | `assets/n/a` |



### Imported Reference Notes

#### Imported: 医学免责声明

⚠️ **重要提示**:本技能提供的数据分析和建议仅供参考,不构成医学诊断或治疗建议。

- 所有性健康问题应由专业医生诊断和治疗
- 分析结果不能替代专业医疗检查
- 紧急情况应立即就医
- 请遵循医生的专业建议

#### Imported: 核心功能

### 1. IIEF-5 评分分析

#### 1.1 交互式问卷

**问卷结构**:
- 5个问题,每个问题0-5分
- 总分范围:0-25分
- 评估时间范围:过去6个月

**问题详解**:

**问题1**:勃起信心
- 评估用户对获得和维持勃起的信心程度
- 反映心理因素对性功能的影响
- 低分可能提示表现焦虑

**问题2**:勃起获得
- 评估受到性刺激时获得勃起的能力
- 反映血管和神经功能
- 低分可能提示器质性ED

**问题3**:插入能力
- 评估勃起硬度是否足够插入
- 临床相关的勃起质量指标
- 低分通常需要医疗干预

**问题4**:勃起维持
- 评估完成性交过程中维持勃起的能力
- 反映静脉闭塞功能
- 与问题3联合分析可确定ED类型

**问题5**:性交满意度
- 评估性交过程的主观满意度
- 受硬度、持续时间、伴侣满意度等多因素影响
- 综合性功能的最终指标

#### 1.2 ED严重程度评估

| 总分 | ED严重程度 | 临床意义 | 推荐措施 |
|------|-----------|----------|----------|
| 22-25 | 正常 | 勃起功能良好 | 继续健康生活方式 |
| 17-21 | 轻度ED | 轻度功能障碍 | 生活方式调整,定期评估 |
| 12-16 | 轻中度ED | 中度功能障碍 | 建议就医评估 |
| 8-11 | 中度ED | 明显功能障碍 | 需要医疗干预 |
| 5-7 | 重度ED | 严重功能障碍 | 全面医疗评估和治疗 |

#### 1.3 趋势分析

**分析维度**:
- 总分变化趋势(改善/稳定/恶化)
- 各问题得分变化模式
- ED严重程度变化轨迹
- 治疗干预效果评估

**输出内容**:
- IIEF-5评分时间序列图表
- 改善/恶化趋势标识
- 变化速率计算
- 与其他健康指标的相关性分析

#### 1.4 风险因素分析

**生理因素**:
- 年龄:每增加10年,ED风险增加约20%
- 糖尿病:ED风险增加3倍
- 心血管疾病:ED风险增加2-3倍
- 高血压:ED风险增加1.5-2倍
- 肥胖:BMI>30增加ED风险
- 荷尔蒙异常:低睾酮水平

**心理因素**:
- 表现焦虑
- 抑郁症状
- 压力水平
- 伴侣关系问题

**生活方式因素**:
- 吸烟:增加ED风险1.5倍
- 酗酒:长期影响性功能
- 缺乏运动:心血管健康下降
- 睡眠质量:影响荷尔蒙分泌

**药物因素**:
- 抗抑郁药(SSRIs等)
- 抗高血压药(β受体阻滞剂、噻嗪类)
- 抗精神病药
- 激素类药物

#### 1.5 改善建议

**生活方式干预**:
- **戒烟**:显著改善血管健康
- **限酒**:男性每日<2杯
- **减重**:BMI控制在18.5-24.9
- **规律运动**:
  - 每周150分钟中等强度有氧运动
  - 每周2-3次力量训练
  - 每日盆底肌训练(凯格尔运动)
- **健康饮食**:
  - 地中海饮食模式
  - 增加水果蔬菜摄入
  - 减少饱和脂肪和加工食品
  - 适量坚果和全谷物

**心理干预**:
- 性治疗师咨询
- 认知行为疗法
- 伴侣治疗
- 压力管理技术(冥想、瑜伽)

**医疗干预**:
- PDE5抑制剂(需医生处方)
- 睾酮补充疗法(如睾酮低)
- 真空勃起装置
- 阴茎注射疗法
- 手术治疗(血管手术、假体)

### 2. STD 筛查管理

#### 2.1 筛查项目详解

**HIV (艾滋病病毒)**:
- **检测方法**:血液检测(抗体+抗原组合)
- **窗口期**:1-3个月
- **高危人群**:MSM、性工作者、多性伴侣者
- **筛查频率**:高风险每3-6个月,一般风险每年

**梅毒 (Syphilis)**:
- **检测方法**:血液检测(RPR/VDRL+TPPA确认)
- **窗口期**:10-90天
- **分期**:一期、二期、潜伏期、三期
- **治疗**:青霉素有效,早期治愈率高

**衣原体 (Chlamydia)**:
- **检测方法**:尿液检测或拭子
- **窗口期**:1-3周
- **特点**:常无症状,但可导致不孕
- **治疗**:阿奇霉素或多西环素

**淋病 (Gonorrhea)**:
- **检测方法**:尿液检测或拭子
- **窗口期**:1-14天
- **特点**:男性症状明显,女性常无症状
- **治疗**:头孢曲松+阿奇霉素(考虑耐药性)

**HPV (人乳头瘤病毒)**:
- **检测方法**:拭子DNA检测
- **窗口期**:1个月-数年
- **特点**:非常常见,大多数自愈
- **高危型**:HPV 16/18与宫颈癌相关
- **预防**:HPV疫苗有效

**乙肝 (Hepatitis B)**:
- **检测方法**:血液检测(HBsAg+抗HBs)
- **窗口期**:1-6个月
- **预防**:乙肝疫苗有效
- **治疗**:抗病毒药物

**生殖器疱疹 (Herpes)**:
- **检测方法**:拭子PCR或血液抗体
- **窗口期**:2-12天
- **特点**:无治愈方法,可控制症状
- **治疗**:抗病毒药物(阿昔洛韦等)

#### 2.2 风险评估

**行为风险因素**:
- 性伴侣数量(>3个/年 = 高风险)
- 保护措施使用频率
- 性伴侣的STD状况
- 性工作或性工作者接触史
- MSM人群
- 注射吸毒史

**动态风险评分**:
- **低风险**(<10分):单一稳定伴侣,坚持保护
- **中风险**(10-30分):2-3个性伴侣,偶尔保护
- **高风险**(30-50分):多性伴侣,保护不一致
- **极高风险**(>50分):性工作者,MSM,无保护

#### 2.3 筛查频率建议

基于风险等级的个性化筛查计划:

| 风险等级 | HIV/梅毒 | 衣原体/淋病 | HPV | 乙肝 |
|----------|---------|------------|-----|------|
| 低风险 | 每1-2年 | 每1-2年 | 每3年 | 已免疫无需检测 |
| 中风险 | 每年 | 每年 | 每3年 | 每1-2年 |
| 高风险 | 每3-6月 | 每3-6月 | 每年 | 每年 |
| 极高风险 | 每3月 | 每3月 | 每6月 | 每6月 |

#### 2.4 阳性结果管理

**立即行动**:
- 开始治疗(遵医嘱)
- 通知性伴侣并进行检测
- 暂停性生活或严格保护
- 避免传播风险

**治疗追踪**:
- 治疗后检测以确认治愈
- 监测药物副作用
- 评估治疗依从性
- 记录治疗过程和结果

**预防再感染**:
- 性伴侣同时治疗
- 治愈后重新开始保护措施
- 定期复查
- 风险教育

#### 2.5 统计分析

- 筛查频率趋势
- 阳性率变化
- 感染类型分布
- 治愈率统计
- 再感染率分析

### 3. 避孕管理

#### 3.1 避孕方法详细分析

**避孕套 (男/女)**:
- **典型使用有效率**:85%
- **完美使用有效率**:98%
- **优点**:
  - 唯一防孕又防病的方法
  - 无激素副作用
  - 易于获取
  - 即刻起效
- **缺点**:
  - 需要每次使用
  - 可能影响性快感
  - 可能破裂或滑落
- **满意度影响因素**:
  - 尺寸是否合适
  - 润滑剂使用
  - 佩戴技巧
  - 品牌偏好

**口服避孕药**:
- **典型使用有效率**:91%
- **完美使用有效率**:99.7%
- **类型**:
  - 复方避孕药(雌激素+孕激素)
  - 单纯孕激素药(适合哺乳期)
  - 24/4方案 vs 21/7方案
- **优点**:
  - 高效避孕
  - 可调节月经周期
  - 改善痤疮和经前综合症
  - 降低卵巢癌和子宫内膜癌风险
- **缺点**:
  - 需要每日服用
  - 激素副作用
  - 不适合吸烟女性>35岁
  - 不能预防STD
- **副作用追踪**:
  - 恶心、乳房胀痛
  - 情绪变化
  - 性欲改变
  - 体重变化
  - 月经间期出血

**宫内节育器 (IUD)**:
- **有效率**:99%+
- **类型**:
  - 铜IUD(10-12年)
  - 左炔诺孕酮IUD(3-8年)
- **优点**:
  - 长效可逆
  - 即刻起效
  - 可随时取出
  - 激素IUD可减轻月经
- **缺点**:
  - 需要医生放置
  - 放置时不适
  - 可能增加月经量和痛经(铜IUD)
  - 不能预防STD
- **副作用追踪**:
  - 放置后疼痛
  - 月经变化
  - 点滴出血
  - 穿孔风险(罕见)

**皮下埋植**:
- **有效率**:99%+
- **持续时间**:3-5年
- **优点**:
  - 长效可逆
  - 放置简单
  - 可随时取出
  - 隐蔽性好
- **缺点**:
  - 激素副作用
  - 可能导致月经紊乱
  - 放置部位可能瘢痕
  - 不能预防STD

**避孕针**:
- **典型使用有效率**:94%
- **完美使用有效率**:99%+
- **频率**:每3个月一次
- **优点**:
  - 不需要每日服用
  - 隐蔽性好
- **缺点**:
  - 需要定期注射
  - 体重增加常见
  - 生育力恢复可能延迟
  - 不能预防STD

**体外射精**:
- **典型使用有效率**:78%
- **完美使用有效率**:96%
- **风险**:
  - 需要高度自控
  - 射精前可能有精子溢出
  - 增加性焦虑
  - 不能预防STD
- **不推荐**:失败率较高

**安全期法**:
- **典型使用有效率**:76-88%
- **完美使用有效率**:95-99%
- **方法**:
  - 日历法
  - 基础体温法
  - 宫颈黏液法
  - 症状体温法
- **风险**:
  - 月经不规律时不可靠
  - 需要严格记录
  - 排卵期可能不规律
  - 不能预防STD
- **不推荐**:失败率较高

**结扎手术**:
- **有效率**:99%+
- **类型**:
  - 输精管结扎(男性)
  - 输卵管结扎(女性)
- **优点**:
  - 永久性避孕
  - 高效
  - 无激素影响
- **缺点**:
  - 通常不可逆
  - 需要手术
  - 术后恢复期
  - 不能预防STD

#### 3.2 效果评估

**避孕失败率分析**:
- Pearl指数(每100女性年失败数)
- 典型使用 vs 完美使用差异
- 使用错误分析
- 失败原因追踪

**满意度评分**:
- 易用性(1-10分)
- 舒适度(1-10分)
- 对性生活影响(1-10分)
- 副作用可接受度(1-10分)
- 整体满意度(1-10分)

#### 3.3 副作用追踪

**荷尔蒙相关副作用**:
- 月经模式改变
- 情绪波动
- 性欲变化
- 体重变化
- 乳房胀痛

**非荷尔蒙副作用**:
- 疼痛或不适(IUD)
- 过敏反应(避孕套)
- 疤痕形成(埋植、结扎)

**严重副作用**:
- 血栓栓塞风险(激素类)
- 异位妊娠风险(IUD失败时)
- 感染风险(IUD放置)

#### 3.4 切换历史

**切换原因分析**:
- 副作用不耐受
- 效果不满意
- 生活方式改变
- 健康状况变化
- 经济原因
- 伴侣偏好

**切换建议**:
- 基于副作用史选择
- 考虑年龄和生育计划
- 评估健康风险因素
- 伴侣讨论

### 4. 性活动日志

#### 4.1 记录内容

**基础信息**:
- 日期和时间
- 活动类型(性交、口交、手交等)
- 持续时间
- 伴侣类型(固定、新伴侣等)

**保护措施**:
- 避孕方法(避孕套、口服避孕药等)
- 是否正确使用
- 是否破损或失败

**主观体验**:
- 满意度评分(1-10分)
- 性欲水平(1-10分)
- 疼痛或不适(有/无,程度)
- 是否达到高潮

**特殊情况**:
- 异常症状
- 避孕失败
- 意外情况
- 备注

#### 4.2 隐私保护

**数据标记**:
- 敏感数据标记
- 加密建议
- 访问权限设置
- 数据匿名化选项

**用户控制**:
- 可选功能,完全自主决定
- 可随时删除记录
- 可选择性导出数据
- 就医时可选择性展示

#### 4.3 统计分析

**频率统计**:
- 每周/每月/每年性活动次数
- 频率变化趋势
- 与年龄/关系阶段对比

**满意度分析**:
- 平均满意度评分
- 满意度趋势变化
- 影响满意度的因素分析
- 与IIEF-5/FSFI评分相关性

**保护措施统计**:
- 保护措施使用率
- 各避孕方法使用频率
- 避孕失败次数和原因
- 保护措施与满意度关系

**模式识别**:
- 性活动时间模式
- 与生理周期关系(女性)
- 与情绪/压力相关性
- 与药物使用相关性

### 5. 关联分析

#### 5.1 与用药模块的关联

**PDE5抑制剂效果追踪**:
- 药物名称和剂量
- 服用频率和时机
- 效果评分(1-10分)
- 副作用记录
- 效果随时间变化
- 与IIEF-5评分相关性
- 成本效益分析

**抗抑郁药对性功能的影响**:
- 药物类别(SSRIs, SNRIs, TCAs等)
- 性功能副作用类型
- 严重程度评估
- 发生时间(用药初期/长期)
- 与性欲、勃起、高潮的关系
- 换药或加药建议

**降压药对性功能的影响**:
- 药物类别(β受体阻滞剂、噻嗪类等)
- ED发生率
- 性欲影响
- 替代药物选择建议

**激素类药物**:
- 睾酮补充治疗
- 雌激素/孕激素
- 性功能影响
- 剂量调整建议

**其他药物**:
- 抗精神病药
- 抗组胺药
- 化疗药物
- 对性功能的影响

#### 5.2 与慢性病模块的关联

**糖尿病与ED**:
- **病理机制**:
  - 血管内皮损伤
  - 神经病变
  - 荷尔蒙异常
- **血糖控制与ED关系**:
  - HbA1c <7%:ED风险较低
  - HbA1c 7-9%:中度风险
  - HbA1c >9%:高度风险
- **糖尿病病程与ED**:
  - <5年:ED风险增加2倍
  - 5-10年:ED风险增加3倍
  - >10年:ED风险增加4-5倍
- **管理建议**:
  - 严格控制血糖
  - 定期ED筛查
  - 早期干预
  - 综合管理(血压、血脂)

**高血压与性功能**:
- **病理机制**:
  - 血管损伤
  - 内皮功能障碍
- **降压药的影响**:
  - β受体阻滞剂:增加ED风险
  - 噻嗪类利尿剂:可能引起ED
  - ACEI/ARB:中性或有益
  - 钙通道阻滞剂:中性
- **管理建议**:
  - 控制血压至目标值
  - 选择对性功能影响小的药物
  - 定期评估性功能

**心血管疾病与性功能**:
- **ED作为预警信号**:
  - ED可能早于心绞痛症状2-3年
  - ED是心血管疾病的独立预测因子
  - 建议ED患者进行心血管评估
- **性生活安全评估**:
  - 心功能分级评估
  - 运动耐量评估
  - 药物使用(硝酸酯类药物禁用PDE5抑制剂)
- **心肌梗死后性生活指导**:
  - 通常2-4周后可恢复
  - 逐步增加强度
  - 监测症状

**肥胖与性功能**:
- **影响机制**:
  - 荷尔蒙变化(睾酮降低,雌激素升高)
  - 血管内皮功能障碍
  - 心理因素(身体意象)
- **减重效果**:
  - 减重5-10%可显著改善
  - 减重后IIEF-5评分平均提高3-5分
  - 运动结合饮食效果最佳

#### 5.3 与心理健康模块的关联

**焦虑与性功能**:
- **表现焦虑**:
  - 担心性表现
  - 害怕不能满足伴侣
  - 导致勃起困难或早泄
- **广泛性焦虑**:
  - 性欲下降
  - 难以放松享受
  - 分心难以集中
- **干预**:
  - 认知行为疗法
  - 放松训练
  - 感觉集中训练

**抑郁与性功能**:
- **抑郁症状与性欲**:
  - 性欲丧失常见症状
  - 性兴趣显著下降
  - 可能是最早出现的症状之一
- **抗抑郁药的双重影响**:
  - 改善抑郁可能恢复性欲
  - 但药物本身可能引起性功能障碍
- **管理策略**:
  - 选择对性功能影响小的抗抑郁药(安非他酮)
  - 加用药物(如丁螺环酮)
  - 剂量调整
  - 心理治疗

**创伤后应激障碍(PTSD)**:
- 性回避
- 性唤起困难
- 闪回影响
- 需要专业创伤治疗

**身体意象**:
- 对自己身体的不满
- 影响性自信
- 导致回避亲密关系
- 身体积极性训练

**伴侣关系**:
- 关系质量与性生活满意度高度相关
- 沟通问题影响性满足
- 冲突未解决影响性欲
- 伴侣治疗可能有益

#### 5.4 与营养模块的关联

**关键营养素**:

**锌**:
- **功能**:睾酮合成必需元素
- **缺乏表现**:性欲下降,ED
- **推荐摄入**:男性11mg/天
- **食物来源**:牡蛎、牛肉、南瓜子、腰果
- **补充建议**:如缺乏可补充15-30mg/天

**精氨酸**:
- **功能**:促进一氧化氮生成,改善血流
- **对ED的潜在益处**:可能轻度改善勃起功能
- **推荐剂量**:3-5g/天
- **食物来源**:坚果、种子、肉类、鱼类
- **注意事项**:可能与某些药物相互作用

**维生素D**:
- **功能**:支持睾酮合成
- **缺乏表现**:低维生素D水平与ED相关
- **目标水平**:血清25(OH)D >30 ng/mL
- **补充建议**:如缺乏可补充1000-2000 IU/天

**镁**:
- **功能**:支持睾酮合成,改善血流
- **推荐摄入**:男性400-420mg/天
- **食物来源**:绿叶蔬菜、坚果、全谷物
- **补充建议**:如缺乏可补充200-400mg/天

**Omega-3脂肪酸**:
- **功能**:改善心血管健康,间接改善性功能
- **推荐摄入**:1-2g EPA+DHA/天
- **食物来源**:深海鱼类、亚麻籽、核桃

**抗氧化物质**:
- **功能**:保护血管内皮
- **重要抗氧化剂**:维生素C、维生素E、硒、番茄红素
- **食物来源**:水果、蔬菜、坚果

**膳食模式**:

**地中海饮食**:
- **特点**:高水果蔬菜、全谷物、橄榄油、鱼类
- **研究证据**:改善ED,降低心血管风险
- **机制**:改善血管健康,降低炎症

**限制**:
- **饱和脂肪**:减少红肉和全脂乳制品
- **反式脂肪**:避免加工食品
- **添加糖**:控制糖分摄入,特别是糖尿病患者
- **酒精**:男性每日<2杯

**营养状况评估**:
- 评估营养素缺乏
- 提供个性化营养建议
- 推荐补充剂(如需要)
- 监测营养改善效果

#### 5.5 与运动模块的关联

**有氧运动**:
- **类型**:快走、跑步、游泳、骑行
- **推荐量**:每周150分钟中等强度
- **对ED的益处**:
  - 改善心血管健康
  - 增强血流
  - 降低ED风险约40%
  - IIEF-5评分平均提高2-4分
- **机制**:
  - 改善内皮功能
  - 增加一氧化氮生物利用度
  - 降低血压和血糖

**力量训练**:
- **类型**:重量训练、抗阻训练
- **推荐量**:每周2-3次
- **对性功能的益处**:
  - 提高睾酮水平
  - 增强肌肉力量和耐力
  - 改善身体意象和自信
- **注意事项**:
  - 避免过度训练
  - 充分恢复

**盆底肌训练(凯格尔运动)**:
- **功能**:
  - 增强勃起硬度和维持能力
  - 改善射精控制
  - 对ED和早泄均有益
- **方法**:
  - 收缩盆底肌肉(如中断排尿)
  - 保持5秒,放松5秒
  - 每日3组,每组10-15次
- **效果**:
  - 6-12周后显著改善
  - IIEF-5评分平均提高3-5分

**瑜伽**:
- **益处**:
  - 改善身体意象和性自信
  - 增强柔韧性和身体意识
  - 降低压力和焦虑
  - 某些体式增强盆底肌
- **推荐**:
  - 每周2-3次
  - 结合冥想和呼吸练习

**运动与性欲**:
- 适度运动提高性欲
- 过度运动可能降低性欲(女运动员三联征)
- 找到平衡点

**运动处方**:
- 基于年龄、健康状况、兴趣
- 渐进式增加
- 结合有氧、力量、柔韧性训练
- 盆底肌训练作为补充

### 6. 风险评估

#### 6.1 ED风险评分

**风险因素加权**:

| 风险因素 | 权重 | 评分 |
|----------|------|------|
| 年龄 | 15% | <40:0, 40-49:1, 50-59:2, 60+:3 |
| 糖尿病 | 20% | 无:0, 控制:1, 未控制:3 |
| 心血管疾病 | 15% | 无:0, 稳定:1, 不稳定:3 |
| 高血压 | 10% | 无:0, 控制:1, 未控制:2 |
| 吸烟 | 10% | 从不:0, 已戒烟:1, 吸烟:2 |
| 酗酒 | 5% | 无:0, 偶尔:1, 经常:2 |
| 肥胖 | 10% | BMI<25:0, 25-30:1, >30:2 |
| 缺乏运动 | 5% | 规律:0, 偶尔:1, 缺乏:2 |
| 压力/焦虑 | 5% | 无:0, 轻度:1, 中重度:2 |
| 药物副作用 | 5% | 无:0, 轻度:1, 明显:2 |

**风险等级**:
- **低风险**(0-20分):ED可能性低
- **中风险**(21-40分):ED风险增加
- **高风险**(41-60分):ED高度可能
- **极高风险**(>60分):几乎肯定有ED

#### 6.2 STD风险评分

**行为因素**:

| 风险因素 | 评分 |
|----------|------|
| 性伴侣数量 | 单一:0, 2-3:5, 4-10:15, >10:30 |
| 保护措施使用 | 总是:0, 通常:5, 有时:15, 从不:30 |
| 性伴侣类型 | 固定:0, 新伴侣/偶尔:10, 性工作者:30 |
| MSM | 否:0, 是:20 |
| 已知伴侣感染 | 无:0, 有:50 |
| 注射吸毒 | 否:0, 是:30 |
| 既往STD史 | 无:0, 1次:10, >1次:20 |

**风险等级**:
- **低风险**(0-10分):STD可能性低
- **中风险**(11-30分):STD风险增加
- **高风险**(31-50分):STD高度可能
- **极高风险**(>50分):需要立即筛查

### 7. 个性化建议

#### 7.1 基于IIEF-5评分的建议

**正常(22-25分)**:
- 继续健康生活方式
- 定期评估(每年)
- 预防性措施

**轻度ED(17-21分)**:
- 生活方式干预优先
- 压力管理
- 限制酒精和戒烟
- 3-6个月后重新评估

**轻中度ED(12-16分)**:
- 生活方式干预
- 考虑PDE5抑制剂
- 心理因素评估
- 建议就医

**中度ED(8-11分)**:
- 积极医疗干预
- PDE5抑制剂
- 考虑其他治疗选项
- 心理咨询

**重度ED(5-7分)**:
- 全面医疗评估
- 多学科治疗
- 可能需要专科转诊
- 伴侣参与

#### 7.2 基于风险评估的建议

**高风险ED**:
- 定期筛查(每3-6个月)
- 积极控制危险因素
- 预防性干预
- 早期治疗

**高风险STD**:
- 频繁筛查(每3个月)
- PrEP(暴露前预防)考虑
- 疫苗接种(HPV、乙肝)
- 风险降低咨询

#### 7.3 生活方式处方

**运动处方**:
- 有氧运动:每周150分钟
- 力量训练:每周2-3次
- 盆底肌训练:每日
- 灵活性训练:每周2-3次

**饮食处方**:
- 地中海饮食模式
- 增加水果蔬菜至5-9份/天
- 全谷物替代精制谷物
- 每周2次深海鱼类
- 限制加工食品和添加糖

**行为处方**:
- 戒烟计划
- 限酒:男性<2杯/天
- 睡眠改善:7-9小时/天
- 压力管理:每日放松练习
- 体重管理:BMI 18.5-24.9

### 8. 预警系统

#### 8.1 定期检查提醒

**IIEF-5评估**:
- 正常:每年
- 轻度ED:每6个月
- 中度以上:每3-6个月

**STD筛查**:
- 基于风险等级个性化设置
- 高风险:每3个月
- 一般风险:每年
- 低风险:每1-2年

**性健康检查**:
- 40岁以下:每1-2年
- 40岁以上:每年
- 慢性病患者:每年

#### 8.2 问题预警

**IIEF-5评分下降**:
- 连续2次评估下降>3分
- 一个月内下降>5分
- ED严重程度升级

**STD高风险行为**:
- 无保护性行为增加
- 性伴侣数量增加
- 已知暴露后未筛查

**避孕失效**:
- 避孕套破裂>2次/月
- 漏服避孕药>2次/月
- IUD位置异常

#### 8.3 趋势预警

**性欲显著下降**:
- 持续>3个月
- 影响生活质量
- 伴侣关系受影响

**满意度持续降低**:
- 平均满意度<5分
- 持续下降趋势
- 需要专业评估

#### Imported: 使用场景

### 场景1:定期性健康评估

**用户请求**:分析最近6个月的性健康状况

**分析流程**:
1. 读取最近6个月的所有性健康记录
2. 分析IIEF-5评分变化趋势
3. 评估STD筛查历史
4. 检查避孕方法有效性
5. 分析用药效果
6. 评估生活方式因素

**输出内容**:
- IIEF-5评分变化曲线
- ED严重程度变化
- 主要风险因素
- 改善建议
- 下次检查时间

### 场景2:ED诊断辅助

**用户请求**:我最近勃起困难,IIEF-5评分15分,什么原因?

**分析流程**:
1. 检索最近IIEF-5评分历史
2. 分析用药记录
3. 评估慢性病控制情况
4. 检查心理状态记录
5. 分析生活方式因素
6. 识别主要原因

**输出内容**:
- ED严重程度:轻中度
- 主要风险因素(如糖尿病控制不佳)
- 可修改因素(如吸烟、缺乏运动)
- 药物影响分析
- 个性化改善计划

### 场景3:避孕方法选择

**用户请求**:我想换一种避孕方法,当前口服避孕药有副作用

**分析流程**:
1. 评估当前避孕方法满意度和副作用
2. 分析健康史和风险因素
3. 考虑年龄和生育计划
4. 对比各种避孕方法的优缺点
5. 识别适合的替代方案

**输出内容**:
- 当前方法问题分析
- 适合的替代方案
- 各方案优缺点对比
- 推荐方案及理由
- 切换时间建议

### 场景4:STD风险评估

**用户请求**:我最近有新伴侣,需要STD筛查吗?

**分析流程**:
1. 评估性行为模式
2. 识别风险因素
3. 计算风险评分
4. 确定需要筛查的项目
5. 设置筛查时间表

**输出内容**:
- 当前风险等级
- 推荐筛查项目
- 筛查时间建议
- 风险降低措施
- 随访计划

### 场景5:多学科联合分析

**用户请求**:我有糖尿病,这对性功能有什么影响?

**分析流程**:
1. 读取糖尿病管理数据
2. 分析血糖控制情况
3. 评估性功能状态
4. 分析两者关联性
5. 评估并发症风险
6. 生成联合管理建议

**输出内容**:
- 糖尿病对性功能的影响机制
- 当前血糖控制与ED风险
- 综合管理策略
- 监测指标建议
- 生活方式干预重点

#### Imported: 数据分析方法

### 定量分析
- 统计描述(均值、中位数、标准差)
- 趋势分析(线性回归、移动平均)
- 相关性分析(Pearson/Spearman相关)
- 风险评分计算(多因素加权)

### 定性分析
- 文本描述分析
- 症状模式识别
- 主诉内容分类
- 满意度评估

### 可视化输出
- IIEF-5评分时间序列图表
- ED严重程度变化图
- STD筛查历史时间线
- 避孕方法效果对比
- 性活动频率统计图
- 风险因素雷达图

#### Imported: 质量保证

### 数据验证
- 检查数据完整性
- 验证数据一致性
- 识别异常值
- 处理缺失数据

### 结果验证
- 医学逻辑检查
- 与临床指南对照
- 专家审查(如有)
- 用户反馈收集

### 持续改进
- 定期更新分析算法
- 引入新的科学证据
- 优化用户体验
- 扩展功能范围

#### Imported: 参考资源

### 临床指南
- WHO性健康指南
- EAU(欧洲泌尿协会)ED指南
- AUA(美国泌尿协会)性功能障碍指南
- CDCSTD筛查和治疗指南
- 中华医学会男科学指南

### 评估工具
- IIEF-5(国际勃起功能指数-5)
- FSFI(女性性功能指数)
- SHEF(性健康评估框架)

### 数据源
- 用户记录数据
- 用药模块数据
- 慢性病模块数据
- 心理模块数据
- 营养模块数据
- 运动模块数据

#### Imported: 局限性

### 系统局限
- 不能替代专业医疗检查
- 不能进行实验室检测
- 不能进行体格检查
- 分析结果受数据质量影响

### 数据局限
- 依赖用户记录准确性
- 可能存在遗漏记录
- 主观评估存在偏差
- 时间跨度可能不足

### 建议局限
- 不能考虑所有个体因素
- 不能预测所有并发症
- 需要结合临床判断
- 不能保证100%准确性

#### Imported: 未来扩展

### 计划功能
- AI辅助诊断
- 个性化治疗方案生成
- 伴侣健康关联分析
- 生殖健康追踪(生育规划)
- 性教育模块

### 研究方向
- 机器学习预测模型
- 基因风险分析
- 个性化预防策略
- 远程医疗集成

---

**版本**: v1.0.0
**最后更新**: 2025-01-06
**维护者**: WellAlly Tech

#### Imported: Limitations

- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.

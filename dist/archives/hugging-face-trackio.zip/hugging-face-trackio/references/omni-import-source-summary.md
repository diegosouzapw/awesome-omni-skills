# Imported Source Summary

- Public skill id: `hugging-face-trackio`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/hugging-face-trackio`
- Upstream support files copied: `4`

## Upstream File Preview

- `.claude-plugin/plugin.json`
- `references/alerts.md`
- `references/logging_metrics.md`
- `references/retrieving_metrics.md`
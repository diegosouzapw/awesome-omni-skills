# Imported Source Summary

- Public skill id: `brand-guidelines-anthropic`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/brand-guidelines-anthropic`
- Upstream support files copied: `1`

## Upstream File Preview

- `LICENSE.txt`
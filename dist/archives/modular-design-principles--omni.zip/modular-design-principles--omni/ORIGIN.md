# Origin for modular-design-principles

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/tech-leads-club/agent-skills`
- Source owner: `tech-leads-club`
- Source repository name: `agent-skills`
- Source branch: `main`
- Source commit: `d41f62b84cff05ca6ea5a380f48daceae3fcce20`
- Source skills path: `packages/skills-catalog/skills`
- Source skill path: `packages/skills-catalog/skills/(architecture)/modular-design-principles`
- Imported public skill id: `modular-design-principles`
- Source license: `MIT + CC-BY-4.0`
- License status: `review-required`
- Sync run id: `20260419T085537.556893+0000-tech-leads-club-agent-skills-weekly`

The original source identity is preserved for review and attribution.

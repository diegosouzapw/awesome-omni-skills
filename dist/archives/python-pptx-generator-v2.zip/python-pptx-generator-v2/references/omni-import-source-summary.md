# Imported Source Summary

- Public skill id: `python-pptx-generator-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-awesome-skills/skills/python-pptx-generator`
- Upstream support files copied: `1`

## Upstream File Preview

- `README.md`
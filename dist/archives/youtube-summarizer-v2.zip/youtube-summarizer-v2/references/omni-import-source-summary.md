# Imported Source Summary

- Public skill id: `youtube-summarizer-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills/skills/youtube-summarizer`
- Upstream support files copied: `4`

## Upstream File Preview

- `CHANGELOG.md`
- `README.md`
- `scripts/extract-transcript.py`
- `scripts/install-dependencies.sh`
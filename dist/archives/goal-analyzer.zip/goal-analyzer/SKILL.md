---
name: goal-analyzer
description: "\u5065\u5eb7\u76ee\u6807\u5206\u6790\u5668\u6280\u80fd workflow skill. Use this skill when the user needs \u5206\u6790\u5065\u5eb7\u76ee\u6807\u6570\u636e\u3001\u8bc6\u522b\u76ee\u6807\u6a21\u5f0f\u3001\u8bc4\u4f30\u76ee\u6807\u8fdb\u5ea6,\u5e76\u63d0\u4f9b\u4e2a\u6027\u5316\u76ee\u6807\u7ba1\u7406\u5efa\u8bae\u3002\u652f\u6301\u4e0e\u8425\u517b\u3001\u8fd0\u52a8\u3001\u7761\u7720\u7b49\u5065\u5eb7\u6570\u636e\u7684\u5173\u8054\u5206\u6790\u3002 and the operator should rely on the packaged workflow, support pack, troubleshooting notes, and provenance links before merging or handing off."
version: "0.0.1"
category: devops
tags: ["goal-analyzer", "devops", "agents", "assets", "examples", "references", "scripts"]
complexity: advanced
risk: safe
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "sickn33"
date_added: "2026-04-13"
date_updated: "2026-04-13"
---

# 健康目标分析器技能

## Overview

This public intake copy packages `plugins/antigravity-awesome-skills-claude/skills/goal-analyzer` from `https://github.com/sickn33/antigravity-awesome-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

The packaged support pack adds a checklist, rubric, playbook, prompt template, router note, and source manifest so reviewers can audit the import as a complete workflow kit instead of a raw file dump.

# 健康目标分析器技能 分析健康目标数据,识别目标模式和进度,评估目标达成情况,并提供个性化目标管理建议。

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: 功能, 医学安全边界, 输出格式, 目标概览, SMART评估, 进度分析.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- 你需要评估健康目标是否符合 SMART 原则，并识别目标设定中的薄弱点。
- 你想跟踪目标进度，并结合营养、运动、睡眠等健康数据做关联分析。
- 你需要面向个人健康管理的目标优化建议、风险提示和阶段性调整方案。
- Use when the request clearly matches the imported source intent: 分析健康目标数据、识别目标模式、评估目标进度,并提供个性化目标管理建议。支持与营养、运动、睡眠等健康数据的关联分析。.
- Use when the operator should preserve upstream workflow detail instead of rewriting the process from scratch.
- Use when provenance needs to stay visible in the answer, PR, or review packet.

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `references/omni-import-playbook.md` | Establishes the workflow, review packet, and provenance expectations before work begins |
| PR review or merge readiness | `references/omni-import-rubric.md` | Turns the imported skill into a checklist-driven review packet instead of an opaque file copy |
| Source or lineage verification | `scripts/omni_import_print_origin.py` | Confirms repository, branch, commit, and imported path quickly |
| Workflow execution | `references/omni-import-checklist.md` | Gives the operator the smallest useful entry point into the support pack |
| Handoff decision | `agents/omni-import-router.md` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. Confirm the user goal, the scope of the imported workflow, and whether this skill is still the right router for the task.
2. Read the overview, playbook, and source summary before loading any upstream support files.
3. Load only the references, examples, prompts, or scripts that materially change the outcome for the current request.
4. Execute the upstream workflow while keeping provenance and source boundaries explicit in the working notes.
5. Validate the result against the checklist, rubric, and expected evidence for the task.
6. Escalate or hand off to a related skill when the work moves out of this imported workflow's center of gravity.
7. Before merge or closure, record what was used, what changed, and what the reviewer still needs to verify.

### Imported Workflow Notes

#### Imported: 功能

### 1. SMART目标验证

验证设定的新目标是否符合SMART原则。

**验证维度**:
- **S**pecific(具体性)
  - 目标是否明确具体
  - 是否有清晰的定义
  - 是否避免模糊表述

- **M**easurable(可衡量性)
  - 是否有可量化的指标
  - 是否有明确的衡量标准
  - 是否可以追踪进度

- **A**chievable(可实现性)
  - 目标是否现实可行
  - 是否考虑了当前状况
  - 是否在合理时间范围内
  - 减重目标:建议每周0.5-1公斤
  - 运动目标:建议每周3-5次,每次30-60分钟

- **R**elevant(相关性)
  - 目标是否与健康相关
  - 是否符合用户整体健康计划
  - 是否与现有目标协调

- **T**ime-bound(有时限)
  - 是否有明确的截止日期
  - 时间框架是否合理
  - 是否有阶段性里程碑

**输出**:
- SMART评分(每个维度1-5分)
- 总体评分和等级(S级/A级/B级/C级)
- 改进建议
- 目标优化方案

**示例评估**:
```json
{
  "goal": "6个月内减重5公斤",
  "smart_scores": {
    "specific": 5,
    "measurable": 5,
    "achievable": 4,
    "relevant": 5,
    "time_bound": 5
  },
  "overall_score": 4.8,
  "grade": "A",
  "assessment": "优秀的SMART目标",
  "suggestions": [
    "建议设定阶段性里程碑(每2个月减重1.5-2公斤)",
    "建议配合运动计划和饮食调整"
  ]
}
```

---

### 2. 目标进度追踪

追踪和分析目标的完成进度。

**追踪内容**:
- **当前进度**
  - 完成百分比
  - 当前数值vs目标数值
  - 剩余差距

- **时间进度**
  - 已用时间占比
  - 剩余时间
  - 进度超前/落后判断

- **速度分析**
  - 平均进度速度(每周/每月)
  - 预计完成时间
  - 是否需要调整计划

- **趋势识别**
  - 进度趋势(加速/稳定/减速)
  - 周期性模式
  - 异常波动检测

**输出**:
- 进度可视化(进度条、百分比)
- 完成概率预测
- 时间预估(乐观/中性/悲观)
- 调整建议

**进度评级**:
- 🟢 **优秀** - 进度超前,预计提前完成
- 🟡 **正常** - 进度符合预期
- 🟠 **落后** - 进度略慢,需要加快
- 🔴 **严重落后** - 进度严重滞后,建议调整目标

---

### 3. 习惯养成分析

分析习惯的养成情况和连续性。

**分析内容**:
- **连续天数追踪**
  - 当前连续天数
  - 历史最长连续天数
  - 平均连续天数

- **完成率统计**
  - 总体完成率
  - 每周完成率
  - 每月完成率
  - 特定星期几完成率

- **习惯强度评估**
  - 习惯固化程度(1-10分)
  - 习惯稳定性评分
  - 自动化程度评估

- **习惯模式识别**
  - 最佳触发时间
  - 常见中断原因
  - 成功因素识别

**习惯养成阶段**:
- **第1-7天** - 启动期(最容易放弃)
- **第8-21天** - 形成期(逐渐稳定)
- **第22-30天** - 巩固期(接近自动化)
- **第31-66天** - 习惯期(基本养成)
- **第67天+** - 自动化期(完全自动化)

**输出**:
- 习惯热图(日历视图)
- 连续天数统计
- 完成率趋势图
- 习惯强度评分
- 习惯堆叠建议

**示例分析**:
```json
{
  "habit": "morning-stretch",
  "current_streak": 21,
  "longest_streak": 21,
  "completion_rate": 95.2,
  "strength_score": 7.5,
  "stage": "巩固期",
  "assessment": "习惯即将形成,继续保持!",
  "next_milestone": 30,
  "suggestions": [
    "继续保持,即将达到30天里程碑",
    "可以尝试添加新的相关习惯"
  ]
}
```

---

### 4. 动机评估与管理

评估和管理用户的动机水平。

**评估内容**:
- **动机评分追踪**
  - 当前动机水平(1-10分)
  - 动机变化趋势
  - 动机波动周期

- **动机因素分析**
  - 内在动机(健康、自我实现)
  - 外在动机(奖励、认可)
  - 社会支持(家人朋友鼓励)

- **动机低谷识别**
  - 动机下降信号
  - 常见低谷时间点
  - 风险时段预警

**动机提升策略**:
- **第2-3周** - 动机下降,需要强调已完成进度
- **第1-2个月** - 疲劳期,需要调整目标和奖励
- **3个月后** - 倦怠期,需要新鲜感和挑战

**输出**:
- 动机趋势图
- 动机低谷预警
- 个性化激励建议
- 奖励机制建议

**激励建议示例**:
- 当动机<5分:回顾初心,降低短期目标
- 当动机5-7分:强调进步,设置小奖励
- 当动机>7分:设定挑战,追求卓越

---

### 5. 成就系统管理

管理基础成就系统的解锁和进度。

**成就类型**:
- **目标相关成就**
  - 🏆 首次目标 - 完成第一个健康目标
  - 🎯 半程达成 - 任意目标完成50%
  - 🎉 目标达成 - 完成一个健康目标
  - ⚡ 提前完成 - 提前完成目标
  - 📈 超额完成 - 超额完成目标

- **习惯相关成就**
  - 🔥 连续7天 - 任意习惯连续7天打卡
  - 💪 连续21天 - 任意习惯连续21天打卡
  - ⭐ 连续30天 - 任意习惯连续30天打卡
  - 🌟 连续66天 - 任意习惯连续66天打卡(完全养成)

- **综合成就**
  - 🏅 多目标并行 - 同时完成3个目标
  - 💎 完美坚持 - 30天习惯完成率100%
  - 🚀 快速进步 - 单周进步最大
  - 👑 长期坚持 - 持续追踪180天

**成就追踪**:
- 已解锁成就列表
- 未解锁成就进度
- 成就解锁时间
- 成就相关建议

**输出**:
- 成就徽章展示
- 成就完成进度
- 下一个可解锁成就
- 成就达成建议

---

### 6. 障碍识别与建议

识别阻碍目标达成的因素,提供解决方案。

**障碍类型**:
- **时间障碍**
  - 忙碌、时间不足
  - 建议:缩短单次时长,增加频率;利用碎片时间

- **动机障碍**
  - 缺乏动力、拖延
  - 建议:设置提醒;寻找伙伴;调整目标

- **环境障碍**
  - 缺乏支持、诱惑过多
  - 建议:改变环境;寻找替代方案;建立支持系统

- **能力障碍**
  - 目标太难、缺乏知识
  - 建议:降低难度;学习知识;寻求专业帮助

- **身体障碍**
  - 疲劳、不适、受伤
  - 建议:休息恢复;调整计划;咨询医生

**输出**:
- 主要障碍识别
- 障碍频率统计
- 个性化解决方案
- 预防性建议

---

### 7. 数据关联分析

将健康目标与其他健康数据进行关联分析。

**关联维度**:
- **减重目标关联**
  - 营养摄入(卡路里、宏量营养素)
  - 运动消耗(频率、强度、时长)
  - 睡眠质量(时长、深度)
  - 体重变化趋势

- **运动目标关联**
  - 睡眠质量(恢复情况)
  - 营养摄入(蛋白质、碳水)
  - 身体指标(体重、体脂率)

- **饮食目标关联**
  - 营养素摄入(维生素、矿物质)
  - 身体指标(血压、血糖)
  - 运动表现

- **睡眠目标关联**
  - 运动时间(晚间运动影响)
  - 饮食时间(晚餐时间、咖啡因)
  - 屏幕时间(蓝光影响)

**分析方法**:
- 相关性分析(Pearson相关系数)
- 回归分析(预测模型)
- 趋势匹配(趋势同步性)
- 因果推断(潜在因果关系)

**输出**:
- 关联强度(强/中/弱)
- 正/负相关关系
- 因果关系推断
- 优化建议

**示例关联**:
```json
{
  "goal": "weight-loss",
  "correlations": [
    {
      "factor": "daily_calories",
      "correlation": -0.75,
      "strength": "强负相关",
      "insight": "每日卡路里摄入与减重进度呈强负相关,降低摄入加速进度"
    },
    {
      "factor": "exercise_frequency",
      "correlation": 0.68,
      "strength": "强正相关",
      "insight": "运动频率与减重进度呈强正相关,建议保持每周4次以上"
    },
    {
      "factor": "sleep_duration",
      "correlation": 0.45,
      "strength": "中等正相关",
      "insight": "睡眠时长影响减重,建议保证7-8小时睡眠"
    }
  ],
  "recommendations": [
    "重点控制卡路里摄入,保持当前运动频率",
    "优化睡眠时长,以提升减重效果"
  ]
}
```

---

### 8. 可视化报告生成

生成包含ECharts图表的HTML交互式报告。

**报告类型**:

#### A. 进度趋势报告
- 折线图展示目标进度随时间变化
- 里程碑标注
- 预测完成时间区间
- 进度速度分析

#### B. 习惯热图报告
- 日历热图展示习惯完成情况
- 颜色深浅表示完成频率
- 连续天数标注
- 完成率统计

#### C. 多目标对比报告
- 环形图展示多个目标完成率
- 优先级排序
- 资源分配建议
- 进度同步性分析

#### D. 动机趋势报告
- 折线图展示动机变化
- 动机与进度相关性
- 动机低谷预警
- 激励建议

#### E. 综合报告
- 包含以上所有图表
- 整体健康状况评估
- 综合改进建议
- 下阶段目标建议

**报告特点**:
- 响应式设计,支持移动端
- 深色/浅色主题切换
- 交互式图表(缩放、筛选)
- 数据表格展示
- 导出PDF功能
- 完全本地化,无需联网

**ECharts图表配置**:
```javascript
// 进度趋势折线图
{
  type: 'line',
  xAxis: { type: 'category', data: ['1月', '2月', '3月', ...] },
  yAxis: { type: 'value', name: '完成%' },
  series: [{
    name: '目标进度',
    type: 'line',
    data: [0, 15, 35, 50, 70, 85, 100],
    smooth: true,
    markLine: {
      data: [{ yAxis: 50, name: '50%里程碑' }]
    }
  }]
}

// 习惯热图
{
  type: 'heatmap',
  xAxis: { type: 'category', data: ['周一', '周二', ...] },
  yAxis: { type: 'category', data: ['第1周', '第2周', ...] },
  visualMap: {
    min: 0, max: 1,
    inRange: { color: ['#ebedf0', '#216e39'] }
  },
  series: [{
    type: 'heatmap',
    data: [[0, 0, 1], [1, 0, 1], [2, 0, 0], ...]
  }]
}

// 目标达成率环形图
{
  type: 'pie',
  radius: ['50%', '70%'],
  series: [{
    type: 'pie',
    radius: ['50%', '70%'],
    data: [
      { value: 70, name: '已完成' },
      { value: 30, name: '未完成' }
    ],
    label: { formatter: '{b}: {c}%' }
  }]
}
```

**输出**:
- HTML文件(包含完整的CSS、JS、ECharts)
- 图表交互功能
- 数据表格
- 分析文本
- 建议列表

---

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @goal-analyzer to handle <task>. Start with the workflow playbook, load only the upstream files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Inspect origin and import state

```bash
python3 skills/goal-analyzer/scripts/omni_import_print_origin.py
```

**Explanation:** Use this before review or troubleshooting when you need to confirm source repository, branch, commit, and path.

### Example 3: Review the support pack before execution

```bash
python3 skills/goal-analyzer/scripts/omni_import_list_support_pack.py
```

**Explanation:** This gives the operator a quick inventory of the imported references, examples, scripts, router notes, and manifest files.

### Example 4: Build a reviewer packet

```text
Review @goal-analyzer using the checklist, rubric, playbook, and source manifest, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.



## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The checklist, rubric, worksheet, template, and playbook are there to make the import auditable, not to hide the source material.

- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.
- Prefer the smallest useful set of support files so the workflow stays auditable and fast to review.
- Keep provenance, source commit, and imported file paths visible in notes and PR descriptions.
- Use the checklist, rubric, worksheet, and playbook together instead of relying on a single section in isolation.
- Treat generated examples as scaffolding; adapt them to the concrete task before execution.
- Route to a stronger native skill when architecture, debugging, design, or security concerns become dominant.



## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `plugins/antigravity-awesome-skills-claude/skills/goal-analyzer`, fails to mention provenance, or does not use the support pack at all.
**Solution:** Re-open the checklist, playbook, source summary, and source manifest. Load only the upstream files that materially change the answer, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Use the operator packet and support-pack listing to point at the exact references, examples, scripts, and router notes that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the router note and related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.



## Related Skills

- `@00-andruia-consultant` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@00-andruia-consultant-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operational packet for this imported skill. Together they provide the checklist, rubric, template, playbook, router guidance, and manifest that the validator expects to see represented in the public skill.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | checklists, rubrics, playbooks, and source summaries | `references/omni-import-checklist.md` |
| `examples` | prompt packets and usage templates | `examples/omni-import-operator-packet.md` |
| `scripts` | origin inspection and support-pack listing | `scripts/omni_import_list_support_pack.py` |
| `agents` | routing and handoff guidance | `agents/omni-import-router.md` |
| `assets` | machine-readable source manifest | `assets/omni-import-source-manifest.json` |

- [Imported intake checklist](references/omni-import-checklist.md)
- [Imported review rubric](references/omni-import-rubric.md)
- [Imported workflow playbook](references/omni-import-playbook.md)
- [Imported source summary](references/omni-import-source-summary.md)
- [Imported operator packet](examples/omni-import-operator-packet.md)
- [Imported prompt template](examples/omni-import-prompt-template.md)
- [Print origin details](scripts/omni_import_print_origin.py)
- [List support pack](scripts/omni_import_list_support_pack.py)

### Imported Reference Notes

#### Imported: 医学安全边界

### 能力范围声明
- ✅ 辅助设定健康目标
- ✅ 追踪和分析目标进度
- ✅ 识别健康行为模式
- ✅ 提供一般性健康改善建议
- ✅ 生成可视化报告

- ❌ 不提供医疗诊断
- ❌ 不开具治疗处方
- ❌ 不替代专业医疗建议
- ❌ 不处理进食障碍或强迫行为

### 危险信号识别
**极端目标警告**:
- 减重目标>每周1公斤
- 增重目标>每周0.5公斤
- 极端卡路里限制(<1200卡/天)
- 过度运动(>2小时/天,7天/周)

**不健康行为迹象**:
- 完成率<30%持续3周
- 动机评分<3分持续2周
- 身体不适报告
- 强迫性行为模式

**转介建议**:
- 出现危险信号时,建议咨询医生
- 有慢性疾病时,建议咨询相关专科
- 设定饮食目标时,建议咨询营养师
- 设定运动目标时,建议咨询健身教练

---

#### Imported: 输出格式

### 目标分析报告
```markdown
# 健康目标分析报告

#### Imported: 目标概览

- 目标: 6个月内减重5公斤
- 开始日期: 2025-01-01
- 目标日期: 2025-06-30
- 当前日期: 2025-03-20

#### Imported: SMART评估

- 具体性: ⭐⭐⭐⭐⭐ (5/5)
- 可衡量性: ⭐⭐⭐⭐⭐ (5/5)
- 可实现性: ⭐⭐⭐⭐ (4/5)
- 相关性: ⭐⭐⭐⭐⭐ (5/5)
- 有时限: ⭐⭐⭐⭐⭐ (5/5)

**总体评分: A (4.8/5)**

#### Imported: 进度分析

- 当前进度: 70%
- 已完成: 3.5公斤 / 5.0公斤
- 时间进度: 27% (79天/180天)
- 进度评级: 🟢 优秀 (进度超前)

### 趋势分析
- 平均速度: 0.77公斤/月
- 预计完成: 2025-05-20 (提前40天)
- 进度趋势: 稳定上升

#### Imported: 习惯追踪

### 早上拉伸习惯
- 当前连续: 21天 🔥
- 历史最长: 21天
- 完成率: 95.2%
- 习惯阶段: 巩固期
- 下一个里程碑: 30天 ⭐

#### Imported: 动机评估

- 当前动机: 8/10
- 动机趋势: 稳定
- 动机状态: 良好

#### Imported: 数据关联分析

### 强相关因素(影响度>60%)
1. 每日卡路里摄入 (负相关 -0.75)
2. 每周运动频次 (正相关 +0.68)
3. 睡眠时长 (正相关 +0.45)

### 建议
- 保持当前卡路里摄入水平
- 继续保持每周4次运动频率
- 优化睡眠时长至7-8小时

#### Imported: 障碍识别

主要障碍: 社交活动饮食控制

解决方案:
- 社交活动前提前规划饮食
- 选择健康餐厅
- 适量控制份量

#### Imported: 成就解锁

🔥 连续21天 - 早上拉伸习惯达成!
🎯 半程达成 - 减重目标完成50%!

#### Imported: 下一步行动

1. 保持当前进度
2. 关注社交活动饮食控制
3. 继续养成早操习惯
4. 准备达成30天里程碑
```

---

#### Imported: 技术实现要点

### 数据读取
- 读取主数据文件: `data-example/health-goals-tracker.json`
- 读取日志文件: `data-example/health-goals-logs/YYYY-MM/YYYY-MM-DD.json`
- 关联数据: `data-example/nutrition-tracker.json`, `fitness-tracker.json` 等

### 数据处理
- 计算完成百分比: `(current_value / target_value) * 100`
- 计算时间进度: `(days_elapsed / total_days) * 100`
- 计算连续天数: 遍历日志,统计连续完成天数
- 计算完成率: `(completed_days / total_days) * 100`
- 计算习惯强度: 基于完成率和连续天数的复合评分

### SMART验证算法
```python
def validate_smart_goal(goal):
    scores = {
        'specific': check_specificity(goal),
        'measurable': check_measurability(goal),
        'achievable': check_achievability(goal),
        'relevant': check_relevance(goal),
        'time_bound': check_time_bound(goal)
    }
    overall = sum(scores.values()) / len(scores)
    grade = get_grade(overall)
    return scores, overall, grade
```

### HTML报告生成
- 使用ECharts 5.x CDN
- 响应式CSS布局
- JavaScript处理图表交互
- 支持深色/浅色主题切换
- 数据从JSON文件动态加载

---

**使用此技能时,始终优先考虑用户的健康和安全!**

#### Imported: Limitations

- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.

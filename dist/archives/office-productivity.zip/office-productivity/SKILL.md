---
name: office-productivity
description: "Office Productivity Workflow Bundle workflow skill. Use this skill when the user needs Office productivity workflow covering document creation, spreadsheet automation, presentation generation, and integration with LibreOffice and Microsoft Office formats and the operator should preserve the upstream workflow, copied support files, and provenance before merging or handing off."
version: "0.0.1"
category: cli-automation
tags: ["office-productivity", "office", "productivity", "covering", "document", "creation", "spreadsheet", "automation"]
complexity: intermediate
risk: safe
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "sickn33"
date_added: "2026-04-15"
date_updated: "2026-04-15"
---

# Office Productivity Workflow Bundle

## Overview

This public intake copy packages `plugins/antigravity-awesome-skills-claude/skills/office-productivity` from `https://github.com/sickn33/antigravity-awesome-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

This intake keeps the copied upstream files intact and uses `EXTERNAL_SOURCE.json` plus `ORIGIN.md` as the provenance anchor for review.

# Office Productivity Workflow Bundle

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: Quality Gates, Limitations.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- Creating office documents programmatically
- Automating document workflows
- Converting between document formats
- Generating reports
- Creating presentations from data
- Processing spreadsheets

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `EXTERNAL_SOURCE.json` | Confirms repository, branch, commit, and imported path before touching the copied workflow |
| Provenance review | `ORIGIN.md` | Gives reviewers a plain-language audit trail for the imported source |
| Workflow execution | `SKILL.md` | Starts with the smallest copied file that materially changes execution |
| Supporting context | `SKILL.md` | Adds the next most relevant copied source file without loading the entire package |
| Handoff decision | `## Related Skills` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. libreoffice-writer - LibreOffice Writer
2. docx-official - Microsoft Word
3. pdf-official - PDF handling
4. Design document template
5. Create document structure
6. Add content programmatically
7. Apply formatting

### Imported Workflow Notes

#### Imported: Workflow Phases

### Phase 1: Document Creation

#### Skills to Invoke
- `libreoffice-writer` - LibreOffice Writer
- `docx-official` - Microsoft Word
- `pdf-official` - PDF handling

#### Actions
1. Design document template
2. Create document structure
3. Add content programmatically
4. Apply formatting
5. Export to required formats

#### Copy-Paste Prompts
```
Use @libreoffice-writer to create ODT documents
```

```
Use @docx-official to create Word documents
```

### Phase 2: Spreadsheet Automation

#### Skills to Invoke
- `libreoffice-calc` - LibreOffice Calc
- `xlsx-official` - Excel spreadsheets
- `googlesheets-automation` - Google Sheets

#### Actions
1. Design spreadsheet structure
2. Create formulas
3. Import data
4. Generate charts
5. Export reports

#### Copy-Paste Prompts
```
Use @libreoffice-calc to create ODS spreadsheets
```

```
Use @xlsx-official to create Excel reports
```

### Phase 3: Presentation Generation

#### Skills to Invoke
- `libreoffice-impress` - LibreOffice Impress
- `pptx-official` - PowerPoint
- `frontend-slides` - HTML slides
- `nanobanana-ppt-skills` - AI PPT generation

#### Actions
1. Design slide template
2. Generate slides from data
3. Add charts and graphics
4. Apply animations
5. Export presentations

#### Copy-Paste Prompts
```
Use @libreoffice-impress to create ODP presentations
```

```
Use @pptx-official to create PowerPoint presentations
```

```
Use @frontend-slides to create HTML presentations
```

### Phase 4: Format Conversion

#### Skills to Invoke
- `libreoffice-writer` - Document conversion
- `libreoffice-calc` - Spreadsheet conversion
- `pdf-official` - PDF conversion

#### Actions
1. Identify source format
2. Choose target format
3. Perform conversion
4. Verify quality
5. Batch process files

#### Copy-Paste Prompts
```
Use @libreoffice-writer to convert documents
```

### Phase 5: Document Automation

#### Skills to Invoke
- `libreoffice-writer` - Mail merge
- `workflow-automation` - Workflow automation
- `file-organizer` - File organization

#### Actions
1. Design automation workflow
2. Create templates
3. Set up data sources
4. Generate documents
5. Distribute outputs

#### Copy-Paste Prompts
```
Use @libreoffice-writer to perform mail merge
```

```
Use @workflow-automation to automate document workflows
```

### Phase 6: Graphics and Diagrams

#### Skills to Invoke
- `libreoffice-draw` - Vector graphics
- `canvas-design` - Canvas design
- `mermaid-expert` - Diagram generation

#### Actions
1. Design graphics
2. Create diagrams
3. Generate charts
4. Export images
5. Integrate with documents

#### Copy-Paste Prompts
```
Use @libreoffice-draw to create vector graphics
```

```
Use @mermaid-expert to create diagrams
```

### Phase 7: Database Integration

#### Skills to Invoke
- `libreoffice-base` - LibreOffice Base
- `database-architect` - Database design

#### Actions
1. Connect to data sources
2. Create forms
3. Design reports
4. Automate queries
5. Generate output

#### Copy-Paste Prompts
```
Use @libreoffice-base to create database reports
```

#### Imported: Office Application Workflows

### LibreOffice
```
Skills: libreoffice-writer, libreoffice-calc, libreoffice-impress, libreoffice-draw, libreoffice-base
Formats: ODT, ODS, ODP, ODG, ODB
```

### Microsoft Office
```
Skills: docx-official, xlsx-official, pptx-official
Formats: DOCX, XLSX, PPTX
```

### Google Workspace
```
Skills: googlesheets-automation, google-drive-automation, gmail-automation
Formats: Google Docs, Sheets, Slides
```

#### Imported: Related Workflow Bundles

- `development` - Application development
- `documentation` - Documentation generation
- `database` - Data integration

#### Imported: Overview

Comprehensive office productivity workflow for document creation, spreadsheet automation, presentation generation, and format conversion using LibreOffice and Microsoft Office tools.

#### Imported: Quality Gates

- [ ] Documents formatted correctly
- [ ] Formulas working
- [ ] Presentations complete
- [ ] Conversions successful
- [ ] Automation tested
- [ ] Files organized

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @office-productivity to handle <task>. Start from the copied upstream workflow, load only the files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Ask for a provenance-grounded review

```text
Review @office-productivity against EXTERNAL_SOURCE.json and ORIGIN.md, then explain which copied upstream files you would load first and why.
```

**Explanation:** Use this before review or troubleshooting when you need a precise, auditable explanation of origin and file selection.

### Example 3: Narrow the copied support files before execution

```text
Use @office-productivity for <task>. Load only the copied references, examples, or scripts that change the outcome, and name the files explicitly before proceeding.
```

**Explanation:** This keeps the skill aligned with progressive disclosure instead of loading the whole copied package by default.

### Example 4: Build a reviewer packet

```text
Review @office-productivity using the copied upstream files plus provenance, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.



## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The goal is to keep provenance explicit and load only the copied source material that materially improves execution.

- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.
- Prefer the smallest useful set of support files so the workflow stays auditable and fast to review.
- Keep provenance, source commit, and imported file paths visible in notes and PR descriptions.
- Point directly at the copied upstream files that justify the workflow instead of relying on generic review boilerplate.
- Treat generated examples as scaffolding; adapt them to the concrete task before execution.
- Route to a stronger native skill when architecture, debugging, design, or security concerns become dominant.



## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `plugins/antigravity-awesome-skills-claude/skills/office-productivity`, fails to mention provenance, or does not use any copied source files at all.
**Solution:** Re-open `EXTERNAL_SOURCE.json`, `ORIGIN.md`, and the most relevant copied upstream files. Load only the files that materially change the answer, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Point at the exact copied references, examples, scripts, or assets that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.



## Related Skills

- `@00-andruia-consultant-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@20-andruia-niche-intelligence-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@2d-games` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operator packet for this imported skill. They should reflect real copied source material, not generic scaffolding.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | copied reference notes, guides, or background material from upstream | `references/n/a` |
| `examples` | worked examples or reusable prompts copied from upstream | `examples/n/a` |
| `scripts` | upstream helper scripts that change execution or validation | `scripts/n/a` |
| `agents` | routing or delegation notes that are genuinely part of the imported package | `agents/n/a` |
| `assets` | supporting assets or schemas copied from the source package | `assets/n/a` |



### Imported Reference Notes

#### Imported: Limitations

- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.

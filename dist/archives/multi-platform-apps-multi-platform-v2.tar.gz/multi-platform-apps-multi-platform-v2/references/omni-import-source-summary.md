# Imported Source Summary

- Public skill id: `multi-platform-apps-multi-platform-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills/skills/multi-platform-apps-multi-platform`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
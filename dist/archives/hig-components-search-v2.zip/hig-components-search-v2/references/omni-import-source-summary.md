# Imported Source Summary

- Public skill id: `hig-components-search-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills/skills/hig-components-search`
- Upstream support files copied: `3`

## Upstream File Preview

- `references/page-controls.md`
- `references/path-controls.md`
- `references/search-fields.md`
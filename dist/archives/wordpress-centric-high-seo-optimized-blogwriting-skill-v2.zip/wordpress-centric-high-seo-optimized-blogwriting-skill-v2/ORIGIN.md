# Origin for wordpress-centric-high-seo-optimized-blogwriting-skill-v2

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `e280b1f2aff20b08b830700b3891604a4efd63de`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills/skills/wordpress-centric-high-seo-optimized-blogwriting-skill`
- Imported public skill id: `wordpress-centric-high-seo-optimized-blogwriting-skill-v2`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260426T172454.370339+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

# Imported Source Summary

- Public skill id: `pptx-official-v3`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-bundle-documents-presentations/skills/pptx-official`
- Upstream support files copied: `55`

## Upstream File Preview

- `LICENSE.txt`
- `html2pptx.md`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-chart.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-chartDrawing.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-diagram.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-lockedCanvas.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-main.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-picture.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-spreadsheetDrawing.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/dml-wordprocessingDrawing.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/pml.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-additionalCharacteristics.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-bibliography.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-commonSimpleTypes.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-customXmlDataProperties.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-customXmlSchemaProperties.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesCustom.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesExtended.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-documentPropertiesVariantTypes.xsd`
- `ooxml/schemas/ISO-IEC29500-4_2016/shared-math.xsd`
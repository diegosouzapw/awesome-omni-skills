# Origin for monte-carlo-validation-notebook

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `89e9867f32697aab54aab1de41eb28bf380ba1d6`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/monte-carlo-validation-notebook`
- Imported public skill id: `monte-carlo-validation-notebook`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260426T205510.728513+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

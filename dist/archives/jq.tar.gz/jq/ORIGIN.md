# Origin for jq

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `99f4722632f1891e6b01d32d87b66e80b7ce0d07`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/jq`
- Imported public skill id: `jq`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260419T082120.423160+0000-sickn33-antigravity-awesome-skills-weekly`

The original source identity is preserved for review and attribution.

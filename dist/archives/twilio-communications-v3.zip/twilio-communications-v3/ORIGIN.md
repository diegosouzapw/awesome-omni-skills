# Origin for twilio-communications-v3

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-bundle-integration-apis/skills/twilio-communications`
- Imported public skill id: `twilio-communications-v3`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260412T140229.143733+0000-sickn33-antigravity-awesome-skills-dashboard-force-full-rescan`

The original source identity is preserved for review and attribution.

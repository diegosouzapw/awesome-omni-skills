# Imported Source Summary

- Public skill id: `apify-content-analytics-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-awesome-skills/skills/apify-content-analytics`
- Upstream support files copied: `1`

## Upstream File Preview

- `reference/scripts/run_actor.js`
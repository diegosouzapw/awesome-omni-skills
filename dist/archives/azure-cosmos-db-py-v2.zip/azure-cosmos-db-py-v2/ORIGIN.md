# Origin for azure-cosmos-db-py-v2

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `222dd0e45cab799f09937121e3b083ed1ac8ec20`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills/skills/azure-cosmos-db-py`
- Imported public skill id: `azure-cosmos-db-py-v2`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260416T184335.320775+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

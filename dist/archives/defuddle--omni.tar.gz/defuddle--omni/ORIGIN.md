# Origin for defuddle

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `03e1196f74cb0b2c9a0b807a8244e9c72dd193b5`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/defuddle`
- Imported public skill id: `defuddle`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260414T194005.499490+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

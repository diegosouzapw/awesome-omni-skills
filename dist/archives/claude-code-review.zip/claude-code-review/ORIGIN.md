# Origin for claude-code-review

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/DataRecce/recce.git`
- Source owner: `DataRecce`
- Source repository name: `recce`
- Source branch: `main`
- Source commit: `11652dee6632ef903aa2123c535743c45fd1a546`
- Source skills path: `.claude/skills`
- Source skill path: `.claude/skills/claude-code-review`
- Imported public skill id: `claude-code-review`
- Source license: `Apache-2.0`
- License status: `compatible`
- Sync run id: `20260330T032707.019966+0000-datarecce-recce-editorial-artifacts`

The original source identity is preserved for review and attribution.

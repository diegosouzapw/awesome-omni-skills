# Attribution for chrome-devtools

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `chrome-devtools`
- Upstream title: `Chrome DevTools Agent`
- Upstream path: `skills/chrome-devtools/`
- Upstream author: `tech-leads-club`
- Upstream source field: `community`
- Source PR: `#32`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `4c47919ff680d27258a8b9713e3f3380befbd2b2`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

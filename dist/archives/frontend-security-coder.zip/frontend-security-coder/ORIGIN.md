# Origin for frontend-security-coder

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2c4a2a752b5febbafaab374914b290679e144bcf`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/frontend-security-coder`
- Imported public skill id: `frontend-security-coder`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260421T035904.661752+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

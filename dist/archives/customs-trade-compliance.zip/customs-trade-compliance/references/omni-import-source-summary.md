# Imported Source Summary

- Public skill id: `customs-trade-compliance`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/customs-trade-compliance`
- Upstream support files copied: `3`

## Upstream File Preview

- `references/communication-templates.md`
- `references/decision-frameworks.md`
- `references/edge-cases.md`
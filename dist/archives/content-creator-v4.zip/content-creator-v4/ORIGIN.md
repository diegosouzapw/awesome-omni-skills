# Origin for content-creator-v4

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-bundle-marketing-growth/skills/content-creator`
- Imported public skill id: `content-creator-v4`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260413T230815.811738+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

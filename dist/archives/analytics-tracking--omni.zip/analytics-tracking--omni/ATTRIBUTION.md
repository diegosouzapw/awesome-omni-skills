# Attribution for analytics-tracking

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `analytics-tracking`
- Upstream title: `Analytics Tracking & Measurement Strategy`
- Upstream path: `skills/analytics-tracking/`
- Upstream author: `sickn33`
- Upstream source field: `community`
- Source PR: `#126`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `032affbbd536f09d7636f0fbbfd35093380dae89`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

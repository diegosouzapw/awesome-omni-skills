# Imported Source Summary

- Public skill id: `apify-audience-analysis`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/apify-audience-analysis`
- Upstream support files copied: `1`

## Upstream File Preview

- `reference/scripts/run_actor.js`
# Origin for carrier-relationship-management

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `7c55ad5908444255b5b58674972bf09333bc0424`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/carrier-relationship-management`
- Imported public skill id: `carrier-relationship-management`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260517T202848.855369+0000-sickn33-antigravity-awesome-skills-weekly`

The original source identity is preserved for review and attribution.

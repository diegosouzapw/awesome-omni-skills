# Origin for seo-content-writer-v3

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `7599751ded79b696fdf3d9b6e2ef32fa5777a663`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-bundle-seo-specialist/skills/seo-content-writer`
- Imported public skill id: `seo-content-writer-v3`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260427T065810.582479+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

# Imported Source Summary

- Public skill id: `citation-management`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/citation-management`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
# Origin for azure-microsoft-playwright-testing-ts

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `54136b9c7f08e83e9ecd37d495ac49b2a368304c`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/azure-microsoft-playwright-testing-ts`
- Imported public skill id: `azure-microsoft-playwright-testing-ts`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260418T211210.715783+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

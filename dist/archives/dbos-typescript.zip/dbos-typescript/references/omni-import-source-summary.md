# Imported Source Summary

- Public skill id: `dbos-typescript`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/dbos-typescript`
- Upstream support files copied: `34`

## Upstream File Preview

- `AGENTS.md`
- `CLAUDE.md`
- `references/_sections.md`
- `references/advanced-patching.md`
- `references/advanced-versioning.md`
- `references/client-enqueue.md`
- `references/client-setup.md`
- `references/comm-events.md`
- `references/comm-messages.md`
- `references/comm-streaming.md`
- `references/lifecycle-config.md`
- `references/lifecycle-express.md`
- `references/pattern-classes.md`
- `references/pattern-debouncing.md`
- `references/pattern-idempotency.md`
- `references/pattern-scheduled.md`
- `references/pattern-sleep.md`
- `references/queue-basics.md`
- `references/queue-concurrency.md`
- `references/queue-deduplication.md`
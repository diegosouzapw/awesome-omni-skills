# Imported Source Summary

- Public skill id: `seo-aeo-keyword-research`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/seo-aeo-keyword-research`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
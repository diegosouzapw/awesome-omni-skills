# Imported Source Summary

- Public skill id: `api-security-best-practices-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills/skills/api-security-best-practices`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
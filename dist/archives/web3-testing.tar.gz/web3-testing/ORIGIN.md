# Origin for web3-testing

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `222dd0e45cab799f09937121e3b083ed1ac8ec20`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/web3-testing`
- Imported public skill id: `web3-testing`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260416T174815.456835+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

# Attribution for conductor-setup-v2

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `conductor-setup-v2`
- Upstream title: `What to Create`
- Upstream path: `skills/conductor-setup-v2/`
- Upstream author: `Shpigford`
- Upstream source field: `community`
- Source PR: `#263`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `96a8b32dc2a22bdb194119e570fe385417bd3d21`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

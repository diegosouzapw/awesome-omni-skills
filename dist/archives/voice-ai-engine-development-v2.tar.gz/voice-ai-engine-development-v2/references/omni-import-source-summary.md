# Imported Source Summary

- Public skill id: `voice-ai-engine-development-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills/skills/voice-ai-engine-development`
- Upstream support files copied: `8`

## Upstream File Preview

- `README.md`
- `examples/complete_voice_engine.py`
- `examples/gemini_agent_example.py`
- `examples/interrupt_system_example.py`
- `references/common_pitfalls.md`
- `references/provider_comparison.md`
- `templates/base_worker_template.py`
- `templates/multi_provider_factory_template.py`
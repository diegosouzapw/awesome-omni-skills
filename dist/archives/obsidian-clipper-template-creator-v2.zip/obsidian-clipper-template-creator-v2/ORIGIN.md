# Origin for obsidian-clipper-template-creator-v2

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `9bad53f2426e310c33ef5bacf9f845855197be6a`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills/skills/obsidian-clipper-template-creator`
- Imported public skill id: `obsidian-clipper-template-creator-v2`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260425T181941.597517+0000-sickn33-antigravity-awesome-skills-dashboard-refresh-native-pr`

The original source identity is preserved for review and attribution.

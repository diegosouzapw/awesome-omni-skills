# Origin for workflow-automation-v2

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `7c55ad5908444255b5b58674972bf09333bc0424`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills/skills/workflow-automation`
- Imported public skill id: `workflow-automation-v2`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260517T213745.317383+0000-sickn33-antigravity-awesome-skills-weekly`

The original source identity is preserved for review and attribution.

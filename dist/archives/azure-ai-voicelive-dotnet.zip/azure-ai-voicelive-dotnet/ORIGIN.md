# Origin for azure-ai-voicelive-dotnet

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `d97d4b858b4e211dbdf0f8487fd5476ab8faddc6`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/azure-ai-voicelive-dotnet`
- Imported public skill id: `azure-ai-voicelive-dotnet`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260421T084724.844466+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

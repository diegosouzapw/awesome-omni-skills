# Imported Source Summary

- Public skill id: `confluence-assistant`
- Source repository: `https://github.com/tech-leads-club/agent-skills`
- Source branch: `main`
- Source commit: `906a57d9bbfa69e6438f1baa17b31db95112fad7`
- Source skill path: `packages/skills-catalog/skills/(development)/confluence-assistant`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
# Imported Source Summary

- Public skill id: `dbos-python`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `a9e6b3ed2a9b17d1410043dd8cd0f24ca93071aa`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/dbos-python`
- Upstream support files copied: `35`

## Upstream File Preview

- `AGENTS.md`
- `CLAUDE.md`
- `references/_sections.md`
- `references/advanced-async.md`
- `references/advanced-patching.md`
- `references/advanced-versioning.md`
- `references/client-enqueue.md`
- `references/client-setup.md`
- `references/comm-events.md`
- `references/comm-messages.md`
- `references/comm-streaming.md`
- `references/lifecycle-config.md`
- `references/lifecycle-fastapi.md`
- `references/pattern-classes.md`
- `references/pattern-debouncing.md`
- `references/pattern-idempotency.md`
- `references/pattern-scheduled.md`
- `references/pattern-sleep.md`
- `references/queue-basics.md`
- `references/queue-concurrency.md`
# Imported Source Summary

- Public skill id: `makepad-layout-v3`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-bundle-makepad-builder/skills/makepad-layout`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
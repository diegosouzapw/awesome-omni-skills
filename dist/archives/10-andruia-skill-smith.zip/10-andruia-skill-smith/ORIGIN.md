# Origin for 10-andruia-skill-smith

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `846ac1c763877775967f0584ea06818e47aa0c2a`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/10-andruia-skill-smith`
- Imported public skill id: `10-andruia-skill-smith`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260424T182246.406785+0000-sickn33-antigravity-awesome-skills-weekly-forced`

The original source identity is preserved for review and attribution.

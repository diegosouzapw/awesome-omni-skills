# Imported Source Summary

- Public skill id: `technical-design-doc-creator-v2`
- Source repository: `https://github.com/tech-leads-club/agent-skills`
- Source branch: `main`
- Source commit: `906a57d9bbfa69e6438f1baa17b31db95112fad7`
- Source skill path: `packages/skills-catalog/skills/(creation)/create-technical-design-doc`
- Upstream support files copied: `1`

## Upstream File Preview

- `README.md`
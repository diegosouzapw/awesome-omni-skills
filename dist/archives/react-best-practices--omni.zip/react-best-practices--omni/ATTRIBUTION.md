# Attribution for react-best-practices

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `react-best-practices`
- Upstream title: `Vercel React Best Practices`
- Upstream path: `skills/react-best-practices/`
- Upstream author: `vercel`
- Upstream source field: `community`
- Source PR: `#133`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `9f1c34bd96b4fc03578ceb26f6303d8bf2c13b42`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

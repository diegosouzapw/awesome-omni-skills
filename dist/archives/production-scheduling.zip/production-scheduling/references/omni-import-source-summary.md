# Imported Source Summary

- Public skill id: `production-scheduling`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2138ff8fd03e70a03e116098923de0bdab3d2748`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/production-scheduling`
- Upstream support files copied: `3`

## Upstream File Preview

- `references/communication-templates.md`
- `references/decision-frameworks.md`
- `references/edge-cases.md`
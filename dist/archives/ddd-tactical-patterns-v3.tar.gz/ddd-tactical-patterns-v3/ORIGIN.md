# Origin for ddd-tactical-patterns-v3

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `846ac1c763877775967f0584ea06818e47aa0c2a`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-bundle-ddd-evented-architecture/skills/ddd-tactical-patterns`
- Imported public skill id: `ddd-tactical-patterns-v3`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260425T030343.506757+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

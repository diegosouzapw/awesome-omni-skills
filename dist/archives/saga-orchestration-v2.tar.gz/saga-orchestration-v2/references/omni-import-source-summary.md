# Imported Source Summary

- Public skill id: `saga-orchestration-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills/skills/saga-orchestration`
- Upstream support files copied: `1`

## Upstream File Preview

- `resources/implementation-playbook.md`
---
name: content-to-pipeline
description: "Content-to-Pipeline: Turning Content Into Revenue workflow skill. Use this skill when the user needs When the user wants to turn content into revenue, build a content-led GTM motion, reverse engineer distribution, or repurpose content across platforms. Also use when the user mentions 'content marketing,' 'content-led growth,' 'content to pipeline,' 'distribution,' 'content repurposing,' 'content strategy,' 'thought leadership,' 'newsletter,' 'content flywheel,' 'organic growth.' This skill covers content-to-revenue systems from creation through pipeline attribution. Do NOT use for technical implementation, code review, or software architecture and the operator should preserve the upstream workflow, copied support files, and provenance before merging or handing off."
version: "0.0.1"
category: development
tags: ["content-to-pipeline", "the", "user", "wants", "turn", "content", "revenue", "build"]
complexity: advanced
risk: caution
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "tech-leads-club"
date_added: "2026-04-14"
date_updated: "2026-04-14"
---

# Content-to-Pipeline: Turning Content Into Revenue

## Overview

This public intake copy packages `packages/skills-catalog/skills/(gtm)/content-to-pipeline` from `https://github.com/tech-leads-club/agent-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

This intake keeps the copied upstream files intact and uses `EXTERNAL_SOURCE.json` plus `ORIGIN.md` as the provenance anchor for review.

# Content-to-Pipeline: Turning Content Into Revenue You are an expert in content-led go-to-market strategy, distribution reverse engineering, multi-platform content repurposing, and content-to-revenue attribution. You combine founder-led content playbooks with systematic distribution frameworks, newsletter monetization, community-driven amplification, and AI-assisted production workflows. You understand that in 2025-2026, content is the primary acquisition channel for capital-efficient companies, and you help founders build systems that turn every piece of content into measurable pipeline. You know that distribution matters more than creation, and that studying what already works is the fastest path to results.

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: Before Starting, 1. The Content Flywheel, 2. Distribution Reverse Engineering, 3. Multi-Platform Content Repurposing Framework, 4. Newsletter as Pipeline, 5. Content-to-DM Conversion.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- Use when the request clearly matches the imported source intent: When the user wants to turn content into revenue, build a content-led GTM motion, reverse engineer distribution, or repurpose content across platforms. Also use when the user mentions 'content marketing,' 'content-led....
- Use when the operator should preserve upstream workflow detail instead of rewriting the process from scratch.
- Use when provenance needs to stay visible in the answer, PR, or review packet.
- Use when copied upstream references, examples, or scripts materially improve the answer.
- Use when the workflow should remain reviewable in the public intake repo before the private enhancer takes over.

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `EXTERNAL_SOURCE.json` | Confirms repository, branch, commit, and imported path before touching the copied workflow |
| Provenance review | `ORIGIN.md` | Gives reviewers a plain-language audit trail for the imported source |
| Workflow execution | `references/podcast-community-cadence.md` | Starts with the smallest copied file that materially changes execution |
| Supporting context | `references/quick-reference.md` | Adds the next most relevant copied source file without loading the entire package |
| Handoff decision | `## Related Skills` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. Confirm the user goal, the scope of the imported workflow, and whether this skill is still the right router for the task.
2. Read the overview and provenance files before loading any copied upstream support files.
3. Load only the references, examples, prompts, or scripts that materially change the outcome for the current request.
4. Execute the upstream workflow while keeping provenance and source boundaries explicit in the working notes.
5. Validate the result against the upstream expectations and the evidence you can point to in the copied files.
6. Escalate or hand off to a related skill when the work moves out of this imported workflow's center of gravity.
7. Before merge or closure, record what was used, what changed, and what the reviewer still needs to verify.

### Imported Workflow Notes

#### Imported: Before Starting

Gather this context before building any content-to-pipeline deliverable:

- What does the business sell, and who is the buyer? Get the core offer, price range, and the job title of the person who signs.
- What content exists today? Ask for volume (posts/week), platforms, and engagement baselines.
- What is the current content-to-revenue path? How do strangers become customers? Map every step.
- Which platform drives the most pipeline today? If unknown, flag measurement as a prerequisite.
- What is the founder's content comfort level? Video, writing, audio, or a mix. This determines the pillar format.
- Is there a newsletter? If yes, get subscriber count, open rate, and click rate. If no, flag as a high-priority gap.
- What tools are in the stack? CRM, email platform, scheduling tools, analytics.
- How much time per week can the founder dedicate to content? This caps the system design.
- What does the competitive content landscape look like? Who in the space creates content that generates visible engagement?
- Is there a community (Slack, Discord, Circle, or similar)? Communities are distribution multipliers.

---

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @content-to-pipeline to handle <task>. Start from the copied upstream workflow, load only the files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Ask for a provenance-grounded review

```text
Review @content-to-pipeline against EXTERNAL_SOURCE.json and ORIGIN.md, then explain which copied upstream files you would load first and why.
```

**Explanation:** Use this before review or troubleshooting when you need a precise, auditable explanation of origin and file selection.

### Example 3: Narrow the copied support files before execution

```text
Use @content-to-pipeline for <task>. Load only the copied references, examples, or scripts that change the outcome, and name the files explicitly before proceeding.
```

**Explanation:** This keeps the skill aligned with progressive disclosure instead of loading the whole copied package by default.

### Example 4: Build a reviewer packet

```text
Review @content-to-pipeline using the copied upstream files plus provenance, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.

### Imported Usage Notes

#### Imported: Examples

- **User says:** "We want content to drive pipeline" → **Result:** Agent asks hours/week and platform where buyer is; recommends one pillar + 10–15 derivatives, 4 hr/week budget, newsletter in 66 days; outlines attribution (self-reported field on forms) and 90-day consistency before evaluating ROI.
- **User says:** "Which platform should we focus on?" → **Result:** Agent asks where ideal buyer is and what content already works; recommends 1 platform for first 30 days then add second; suggests cadence (LinkedIn 3–5x/week, X 2–3x/day) and founder-led vs company page (5–7x engagement).
- **User says:** "Content doesn't convert to deals" → **Result:** Agent checks DM flow (value-led, 40–60% response target) and nurture length vs sales cycle; suggests clear CTA per piece and content-sourced pipeline target (20–40%); ties to social-selling for DM conversion.

## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The goal is to keep provenance explicit and load only the copied source material that materially improves execution.

- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.
- Prefer the smallest useful set of support files so the workflow stays auditable and fast to review.
- Keep provenance, source commit, and imported file paths visible in notes and PR descriptions.
- Point directly at the copied upstream files that justify the workflow instead of relying on generic review boilerplate.
- Treat generated examples as scaffolding; adapt them to the concrete task before execution.
- Route to a stronger native skill when architecture, debugging, design, or security concerns become dominant.



## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `packages/skills-catalog/skills/(gtm)/content-to-pipeline`, fails to mention provenance, or does not use any copied source files at all.
**Solution:** Re-open `EXTERNAL_SOURCE.json`, `ORIGIN.md`, and the most relevant copied upstream files. Load only the files that materially change the answer, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Point at the exact copied references, examples, scripts, or assets that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.

### Imported Troubleshooting Notes

#### Imported: Troubleshooting

- **No attribution from content** → **Cause:** No "How did you hear about us?" or self-reported attribution. **Fix:** Add required field on every form; tag UTM on all links; review 90-day data before judging.
- **Creating content but no distribution** → **Cause:** Posting without repurposing or DMs. **Fix:** 1 pillar → 10–15 derivatives; add newsletter and DM outreach; use community and build-in-public for trust.
- **Engagement but no pipeline** → **Cause:** CTA missing or too late. **Fix:** One clear next step per piece (DM, reply, asset); track DM-to-call (15–25%); shorten nurture if deal size is small.

---


For checklists, benchmarks, and discovery questions read `references/quick-reference.md` when you need detailed reference.

---

## Related Skills

- `@accessibility` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@ai-cold-outreach` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@ai-pricing` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@ai-sdr` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operator packet for this imported skill. They should reflect real copied source material, not generic scaffolding.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | copied reference notes, guides, or background material from upstream | `references/podcast-community-cadence.md` |
| `examples` | worked examples or reusable prompts copied from upstream | `examples/n/a` |
| `scripts` | upstream helper scripts that change execution or validation | `scripts/n/a` |
| `agents` | routing or delegation notes that are genuinely part of the imported package | `agents/n/a` |
| `assets` | supporting assets or schemas copied from the source package | `assets/n/a` |

- [podcast-community-cadence.md](references/podcast-community-cadence.md)
- [quick-reference.md](references/quick-reference.md)
- [podcast-community-cadence.md](references/podcast-community-cadence.md)
- [quick-reference.md](references/quick-reference.md)

### Imported Reference Notes

#### Imported: 1. The Content Flywheel

Content-led GTM is not a channel. It is a system. Every piece of content should serve multiple purposes: attract attention, build trust, capture leads, nurture prospects, and generate attribution data that proves ROI.

### The Five-Stage Flywheel

```
    CREATE --> DISTRIBUTE --> ENGAGE --> CONVERT --> MEASURE
       ^                                               |
       |                                               |
       +----------- feedback loop --------------------+
```

| Stage | What Happens | Key Metric |
|---|---|---|
| Create | Produce one pillar piece per week (long-form post, video, or podcast episode) | Pillar pieces published per week |
| Distribute | Repurpose into 8-12 platform-native pieces across channels | Distribution ratio (derivatives per pillar) |
| Engage | Respond to every comment, DM, and reply within 2 hours | Response rate and time-to-reply |
| Convert | Move engaged prospects to owned channels (newsletter, DMs, calls) | Email subscribers gained, DMs opened, calls booked |
| Measure | Track first-touch and multi-touch attribution from content to closed deal | Content-sourced pipeline and revenue |

### Why Flywheels Beat Funnels

Funnels are linear and leak. Flywheels compound. Every subscriber who shares your newsletter becomes a distribution node. Every comment thread becomes a trust signal. Every case study becomes content that generates the next case study.

The math: a founder posting 4x/week on LinkedIn with a 2% engagement rate and 50,000 followers generates 4,000 engagements/week. If 1% of those convert to newsletter subscribers, that is 40 new subscribers/week or 2,000/year. At a 2% subscriber-to-customer conversion rate and a $5,000 ACV, that newsletter alone generates $200,000 in annual pipeline.

---

#### Imported: 2. Distribution Reverse Engineering

The biggest mistake in content strategy: creating first, then figuring out distribution. Reverse the order. Study what already works, then create content designed for the distribution channels where your audience pays attention.

### The Reverse Engineering Process

| Step | Action | Tools |
|---|---|---|
| 1 | Identify 10-15 accounts in your space with high engagement | SparkToro, Social Blade, manual search |
| 2 | Export their top 50 performing posts from the last 90 days | Viral Findr, manual scroll, Taplio (LinkedIn) |
| 3 | Categorize by format (thread, carousel, short video, long-form) | Spreadsheet |
| 4 | Tag recurring patterns: hooks, structures, topics, CTAs | Manual analysis |
| 5 | Identify the distribution channels where those posts travel | Check reposts, quote tweets, newsletter mentions |
| 6 | Build your content templates from the patterns that repeat | Template library |
| 7 | Test 10 pieces using those templates with your own expertise | Publish and measure |
| 8 | Double down on the formats and topics that outperform your baseline | Data-driven iteration |

### What to Look For in Top-Performing Content

| Pattern | Why It Works | How to Adapt |
|---|---|---|
| Personal story + lesson | Builds trust faster than abstract advice | Use your own founder journey, not hypotheticals |
| Contrarian takes | Breaks the scroll by challenging assumptions | Only take positions you genuinely hold |
| Data-backed claims | Creates shareability and perceived authority | Pull from your product data, customer results, or industry reports |
| Step-by-step frameworks | High save rate because of perceived utility | Turn your actual processes into numbered frameworks |
| Before/after transformations | Visual proof of value | Use customer screenshots, metric changes, workflow comparisons |

### Audience Research Stack

| Tool | What It Reveals | Cost |
|---|---|---|
| SparkToro | Which accounts, podcasts, and sites your audience follows | Free tier available |
| Social Blade | Growth trends for competitor accounts (anomalies signal viral content) | Free |
| Viral Findr | Aggregated top-performing content by account | Paid |
| Taplio | LinkedIn-specific analytics and content discovery | Paid |
| X Advanced Search | Filter by engagement thresholds, date range, account | Free |
| BuzzSumo | Content performance by topic, domain, and social shares | Paid |

---

#### Imported: 3. Multi-Platform Content Repurposing Framework

One pillar piece should become 10+ platform-native derivatives. This is not copy-paste. Each platform has its own format, tone, and algorithm. The goal is to maintain the core insight while adapting the delivery.

### The Pillar-to-Platform Map

```
                    +------------------+
                    |  PILLAR CONTENT  |
                    | (Newsletter,     |
                    |  Long Video, or  |
                    |  Long-Form Post) |
                    +--------+---------+
                             |
        +--------------------+--------------------+
        |          |          |          |         |
   +---------+ +------+ +--------+ +-------+ +--------+
   |LinkedIn | |  X   | |YouTube | |Email  | |Podcast |
   |3-4 posts| |5-8   | |1 long  | |Weekly | |1 ep or |
   |per week | |posts | |+ 3-5   | |send   | |clips   |
   |         | |daily | |Shorts  | |       | |        |
   +---------+ +------+ +--------+ +-------+ +--------+
```

### Platform-Specific Adaptation Rules

| Platform | Format | Tone | Algorithm Priority | Posting Cadence |
|---|---|---|---|---|
| LinkedIn | Text posts (1200-1500 chars), carousels, newsletters | Professional but personal, story-driven | Dwell time, comments, reposts | 3-5x/week |
| X (Twitter) | Single posts, threads (3-7 posts), quote tweets | Sharp, concise, opinionated | Replies, bookmarks, reposts | 2-3x/day |
| YouTube | Long-form (8-15 min) + Shorts (30-60 sec) | Educational, high production value | Watch time, CTR on thumbnails | 1-3x/week |
| Newsletter | 800-1500 words, one clear takeaway per issue | Conversational, direct, personal | Open rate, click rate | 1-2x/week |
| Podcast | 20-45 min episodes or guest appearances | Conversational, deep-dive | Completion rate, subscriber growth | 1x/week |

### The 4-Hour Weekly Content System

Modeled on high-output solo creators who produce consistent, multi-platform content without a team. The system runs on one pillar piece that feeds everything else.

| Time Block | Activity | Output |
|---|---|---|
| Monday (90 min) | Write pillar piece (newsletter or long-form post) | 1 pillar piece |
| Tuesday (30 min) | Extract 3-4 LinkedIn posts from pillar | 3-4 LinkedIn posts scheduled |
| Tuesday (30 min) | Extract 5-8 X posts and 1-2 threads from pillar | Week of X content scheduled |
| Wednesday (30 min) | Record short video or voice memo riffing on pillar topic | 1 YouTube Short or podcast clip |
| Thursday (30 min) | Engage: reply to every comment, DM warm prospects | Relationship building |
| Friday (30 min) | Review analytics, note what performed, plan next pillar | Data for next cycle |

**Total: 4 hours/week for 15-20 pieces of content across platforms.**

### AI-Assisted Production Workflow

AI accelerates production without replacing the founder's voice and taste. The human provides the insight, experience, and editorial judgment. AI handles the format-shifting grunt work.

| Task | AI Role | Human Role |
|---|---|---|
| Draft generation | Produce first draft from outline or voice memo transcript | Edit for voice, accuracy, and insight |
| Repurposing | Convert long-form to platform-native formats | Approve tone and select final versions |
| Hook writing | Generate 10 hook variations per post | Pick the one that matches the real message |
| Analytics summary | Aggregate performance data into weekly report | Interpret trends and adjust strategy |
| Scheduling | Auto-schedule based on optimal time windows | Override when context demands it |

**Warning**: AI-generated content without founder editing reads as generic. The value is in the founder's unique perspective, not the format. Use AI for speed, not for thinking.

---

#### Imported: 4. Newsletter as Pipeline

Email is the only owned distribution channel. Social platforms can change algorithms overnight. A newsletter subscriber list is yours. In 2025-2026, the median time for a new newsletter to earn its first dollar dropped to 66 days, and the most successful newsletters run 2-4 revenue streams simultaneously.

### Newsletter-to-Revenue Architecture

```
+-------------------+     +------------------+     +----------------+
|  SOCIAL CONTENT   | --> | NEWSLETTER SIGNUP| --> | NURTURE        |
|  (awareness)      |     | (capture)        |     | SEQUENCE       |
+-------------------+     +------------------+     +-------+--------+
                                                           |
                          +------------------+             |
                          |  SEGMENTED       | <-----------+
                          |  OFFERS          |
                          +--------+---------+
                                   |
                    +--------------+--------------+
                    |              |              |
              +-----------+ +----------+ +------------+
              | Product   | | Service  | | Affiliate/ |
              | Launch    | | Offering | | Sponsorship|
              +-----------+ +----------+ +------------+
```

### Newsletter Monetization Layers

| Revenue Stream | When to Add | Expected Revenue per 1K Subscribers |
|---|---|---|
| Sponsorships/Ads | At 2,000+ subscribers with consistent opens | $25-75 per send |
| Digital products (courses, templates) | At 1,000+ with validated demand | $50-200 per launch cycle |
| Paid subscriptions | At 5,000+ with strong free engagement | $5-15/month per paid subscriber |
| Services/consulting | From day one if time permits | Variable, highest per-unit revenue |
| Affiliate partnerships | At 1,000+ with relevant audience | $10-50 per conversion |
| Boosts/Paid recommendations | Platform-specific (Beehiiv, Substack) | $1-3 per new subscriber referred |

### Platform Comparison for Newsletter Pipeline

| Feature | Beehiiv | ConvertKit (Kit) | Substack |
|---|---|---|---|
| Best for | Growth-focused creators, monetization | Automation-heavy creator businesses | Writers prioritizing simplicity |
| Monetization | Ads, Boosts, subscriptions, 0% platform fee | Commerce, Sponsor Network, tips | Paid subscriptions (10% fee) |
| Automation | Basic sequences | Advanced workflows and segmentation | Minimal |
| Audience ownership | Full | Full | Full (with export) |
| Discovery/network | Beehiiv Boost network | Creator Network | Substack recommendations |
| Analytics | Strong, built-in | Strong, tag-based | Basic |
| Pipeline integration | API + Zapier to CRM | Native CRM integrations | Limited |

### Newsletter Growth Tactics

| Tactic | Expected Growth Rate | Effort Level |
|---|---|---|
| Lead magnet on every social post CTA | 50-200 subscribers/month | Low |
| Cross-promotions with similar newsletters | 100-500/month | Medium |
| Beehiiv Boosts (paid acquisition) | Depends on spend, $1-3/sub | Low |
| Gated content (PDF, checklist, template) | 100-300/month | Medium |
| Referral program with tiered rewards | 10-20% monthly growth | Medium |
| Podcast guest appearances with CTA | 50-200 per appearance | High |
| LinkedIn newsletter feature | 500-2000 at launch from existing network | Low |

---

#### Imported: 5. Content-to-DM Conversion

Social content builds awareness. DMs build pipeline. The bridge between them is the engagement-to-conversation transition, moving someone from passive consumer to active prospect without feeling like a cold pitch.

### The DM Conversion Playbook

| Stage | Action | Example |
|---|---|---|
| 1. Engagement trigger | Prospect comments on your post or shares it | "Great breakdown of the pricing model" |
| 2. Public reply | Respond thoughtfully, add value, ask a question | "Thanks - which part resonated most with your situation?" |
| 3. Profile check | Verify they match your ICP before DMing | Check title, company, and activity |
| 4. Value-first DM | Send something useful, not a pitch | "Saw your comment - here is the full framework as a PDF" |
| 5. Qualification | Include 1-2 light questions in the DM | "What is your biggest challenge with X right now?" |
| 6. Bridge to call | If qualified, suggest a 15-min conversation | "Happy to walk through how we solved this for [similar company]" |

### DM Conversion Rules

- Never pitch in the first message. Lead with value.
- Only DM people who engaged with your content first. Cold DMs from content creators feel like bait-and-switch.
- Keep the first DM under 3 sentences. Long DMs get skipped.
- Reference their specific comment or share. Generic DMs signal automation.
- Use "engagement assets" (PDFs, datasets, frameworks) as the reason for the DM. This creates a natural conversation bridge.
- Track DM-to-call conversion rate. Benchmark: 15-25% of qualified DMs should convert to a call.

### LinkedIn DM Funnel Metrics

| Metric | Benchmark | Action If Below |
|---|---|---|
| Engagement-to-DM rate | 5-10% of qualified engagers | Improve public reply quality |
| DM open rate | 80%+ | Improve first-line hook |
| DM response rate | 40-60% | Lead with more specific value |
| DM-to-call rate | 15-25% of responses | Improve qualification questions |
| Call-to-opportunity rate | 30-50% | Tighten ICP criteria for who gets DMed |

---

#### Imported: 6. Founder-Led Content vs. Team Content

### When to Use Each

| Dimension | Founder-Led | Team-Led |
|---|---|---|
| Trust level | Highest - buyers want to hear from founders | Lower - perceived as marketing |
| Scalability | Limited by founder time | Scales with team size |
| Authenticity | Inherently authentic if genuine | Requires strong brand voice guidelines |
| Content types | Opinions, lessons, behind-the-scenes, vision | How-tos, tutorials, case studies, SEO content |
| Pipeline impact | 5-7x higher engagement vs. company pages | Broader coverage, lower per-piece impact |
| Best platforms | LinkedIn, X, podcast guest spots | Blog, YouTube, documentation, SEO |

### The Founder Content Leverage Model

Founders should not try to do everything. The highest-leverage content activities for founders are:

1. **Weekly pillar creation** - the unique insight only you have
2. **Comment engagement** - 15 minutes/day replying to build relationships
3. **Strategic DMs** - 5-10 per week to high-value prospects who engaged
4. **Podcast guesting** - 1-2 per month for borrowed audience distribution

Everything else (SEO content, tutorials, product updates, social scheduling) should be delegated to team members or AI-assisted workflows.

### Transition Timeline: Solo to Team Content

| Stage | Team Size | Founder Role | Content Volume |
|---|---|---|---|
| Solo (0-$500K ARR) | Founder only | Does everything | 4-8 pieces/week |
| Assisted ($500K-$2M) | Founder + 1 content person | Creates pillar, delegates repurposing | 12-20 pieces/week |
| Team ($2M-$10M) | Founder + 2-3 content people | Creates 1-2 pillar pieces, reviews team output | 25-40 pieces/week |
| Scaled ($10M+) | Founder + content team + agency | Thought leadership only, monthly cadence | 50+ pieces/week |

---

#### Imported: 7. Building in Public as GTM

Building in public means sharing your journey transparently: the wins, the losses, the decisions, and the numbers. In 2025, 81% of buyers say they must trust a brand before purchasing. Transparency accelerates that trust.

### What to Share (and What to Keep Private)

| Share Publicly | Keep Private |
|---|---|
| Revenue milestones (MRR, ARR growth) | Specific customer names (without permission) |
| Product development decisions and tradeoffs | Proprietary algorithms or unique IP |
| Hiring challenges and team growth | Internal team conflicts |
| Customer feedback and how you responded | Confidential customer data |
| Failed experiments and lessons learned | Financial details that could hurt fundraising |
| Strategic pivots and why you made them | Plans competitors could directly copy |

### Building in Public Content Calendar

| Day | Content Type | Example |
|---|---|---|
| Monday | Metric Monday - share one number from last week | "Last week: 47 demos booked from LinkedIn alone" |
| Tuesday | Behind the scenes - show how something gets built | Screenshot of product iteration with context |
| Wednesday | Lesson learned - share a mistake and what you took from it | "We spent 3 months on a feature nobody asked for" |
| Thursday | Customer story - share a win (with permission) | "How [Company] cut onboarding time by 60% using our tool" |
| Friday | Founder reflection - personal insight about the journey | "Week 47 of building this company. Here is what changed." |

### Measuring Build-in-Public Impact

| Metric | Target | Tracking Method |
|---|---|---|
| Follower growth rate | 5-10% monthly | Platform analytics |
| Inbound DMs per week | 10-20+ | Manual count |
| "How did you hear about us?" responses mentioning social | 30%+ of new leads | CRM self-reported field |
| Newsletter signups from social | 50-200/month | UTM tracking |
| Press/podcast inbounds | 1-2/month | Inbox tracking |

---

#### Imported: 8. Content Attribution and Pipeline Tracking

The hardest part of content-led GTM is proving it works. Traditional analytics miss 90%+ of content's influence because buyers consume content anonymously, across devices, over weeks or months before converting.

### The Dual Attribution Model

Run both models simultaneously. Neither is complete alone.

| Model | What It Captures | Limitation |
|---|---|---|
| Software-based (UTM, cookies, CRM) | Direct clicks, form fills, tracked page views | Misses dark social, word-of-mouth, content consumed without clicking |
| Self-reported ("How did you hear about us?") | The buyer's own perception of what influenced them | Subject to recency bias, may not name specific content |

### Attribution Implementation Checklist

| Step | Action | Tool |
|---|---|---|
| 1 | Add "How did you hear about us?" as required field on every form | CRM or form builder |
| 2 | Tag all social links with UTM parameters | UTM builder + link shortener |
| 3 | Track newsletter-to-website-to-demo path | Email platform + analytics |
| 4 | Run monthly pipeline review: which content touched which deals | CRM + manual review |
| 5 | Ask in sales calls: "What content of ours have you seen?" | Sales process script |
| 6 | Build a content influence dashboard showing touched vs. sourced pipeline | CRM reporting |

### Content Pipeline Metrics

| Metric | Definition | Benchmark |
|---|---|---|
| Content-sourced pipeline | Deals where content was the first touch | 20-40% of total pipeline for content-led companies |
| Content-influenced pipeline | Deals where content touched the buyer at any stage | 50-70% of total pipeline |
| Content-to-lead conversion rate | Visitors from content who become leads | 1-3% |
| Newsletter-to-pipeline rate | Subscribers who enter the sales pipeline | 2-5% annually |
| Social-to-newsletter conversion | Social followers who subscribe to email | 0.5-2% monthly |
| Time from first content touch to deal close | Average duration of content-influenced deals | 30-90 days (varies by ACV) |

### Dark Social and Unmeasurable Influence

"Dark social" refers to content sharing that happens in private channels: DMs, Slack groups, text messages, verbal recommendations. This is where most B2B buying decisions actually form. You cannot track it with software.

Proxy signals for dark social influence:

- Direct traffic spikes after a viral post (people typing your URL from memory)
- Self-reported attribution mentioning "saw it on LinkedIn/Twitter" without a tracked click
- Inbound emails referencing specific content you published
- Podcast hosts citing your content when inviting you as a guest
- Branded search volume increases correlated with content publishing cadence

---


For podcast/video as pipeline, community-led distribution, and content cadence framework read `references/podcast-community-cadence.md`.

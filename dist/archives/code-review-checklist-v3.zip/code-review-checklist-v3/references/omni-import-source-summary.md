# Imported Source Summary

- Public skill id: `code-review-checklist-v3`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-bundle-qa-testing/skills/code-review-checklist`
- Upstream support files copied: `0`

## Upstream File Preview

- `none`
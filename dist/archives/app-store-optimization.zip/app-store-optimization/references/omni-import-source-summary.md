# Imported Source Summary

- Public skill id: `app-store-optimization`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/app-store-optimization`
- Upstream support files copied: `12`

## Upstream File Preview

- `HOW_TO_USE.md`
- `README.md`
- `ab_test_planner.py`
- `aso_scorer.py`
- `competitor_analyzer.py`
- `expected_output.json`
- `keyword_analyzer.py`
- `launch_checklist.py`
- `localization_helper.py`
- `metadata_optimizer.py`
- `review_analyzer.py`
- `sample_input.json`
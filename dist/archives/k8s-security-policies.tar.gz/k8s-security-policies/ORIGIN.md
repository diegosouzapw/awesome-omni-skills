# Origin for k8s-security-policies

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `d97d4b858b4e211dbdf0f8487fd5476ab8faddc6`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/k8s-security-policies`
- Imported public skill id: `k8s-security-policies`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260421T191637.920725+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

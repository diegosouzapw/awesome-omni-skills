# Imported Source Summary

- Public skill id: `product-manager-toolkit`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/product-manager-toolkit`
- Upstream support files copied: `3`

## Upstream File Preview

- `references/prd_templates.md`
- `scripts/customer_interview_analyzer.py`
- `scripts/rice_prioritizer.py`
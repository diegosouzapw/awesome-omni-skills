# Origin for frontend-mobile-development-component-scaffold

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `54136b9c7f08e83e9ecd37d495ac49b2a368304c`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/frontend-mobile-development-component-scaffold`
- Imported public skill id: `frontend-mobile-development-component-scaffold`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260419T022636.057924+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

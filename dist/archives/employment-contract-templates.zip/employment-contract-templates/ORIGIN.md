# Origin for employment-contract-templates

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/employment-contract-templates`
- Imported public skill id: `employment-contract-templates`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260412T045533.000248+0000-sickn33-antigravity-awesome-skills-weekly`

The original source identity is preserved for review and attribution.

# Imported Source Summary

- Public skill id: `apify-audience-analysis`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/apify-audience-analysis`
- Upstream support files copied: `1`

## Upstream File Preview

- `reference/scripts/run_actor.js`
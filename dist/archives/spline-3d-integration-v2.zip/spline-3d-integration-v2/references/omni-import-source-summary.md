# Imported Source Summary

- Public skill id: `spline-3d-integration-v2`
- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `f2d80cea0b5a0f84500cbd0f0969dabf5d3f6bff`
- Source skill path: `plugins/antigravity-awesome-skills/skills/spline-3d-integration`
- Upstream support files copied: `7`

## Upstream File Preview

- `examples/interactive-scene.tsx`
- `examples/react-spline-wrapper.tsx`
- `examples/vanilla-embed.html`
- `guides/COMMON_PROBLEMS.md`
- `guides/PERFORMANCE.md`
- `guides/REACT_INTEGRATION.md`
- `guides/VANILLA_INTEGRATION.md`
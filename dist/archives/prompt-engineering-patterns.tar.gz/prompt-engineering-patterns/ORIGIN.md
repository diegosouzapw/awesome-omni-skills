# Origin for prompt-engineering-patterns

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `54136b9c7f08e83e9ecd37d495ac49b2a368304c`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/prompt-engineering-patterns`
- Imported public skill id: `prompt-engineering-patterns`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260419T040900.594877+0000-sickn33-antigravity-awesome-skills-weekly`

The original source identity is preserved for review and attribution.

---
name: explain-like-socrates
description: "EXPLAIN LIKE SOCRATES workflow skill. Use this skill when the user needs > and the operator should rely on the packaged workflow, support pack, troubleshooting notes, and provenance links before merging or handing off."
version: "0.0.1"
category: ai-agents
tags: ["explain-like-socrates", "ai-agents", "agents", "assets", "examples", "references", "scripts"]
complexity: advanced
risk: safe
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "sickn33"
date_added: "2026-04-12"
date_updated: "2026-04-12"
---

# EXPLAIN LIKE SOCRATES

## Overview

This public intake copy packages `plugins/antigravity-awesome-skills-claude/skills/explain-like-socrates` from `https://github.com/sickn33/antigravity-awesome-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

The packaged support pack adds a checklist, rubric, playbook, prompt template, router note, and source manifest so reviewers can audit the import as a complete workflow kit instead of a raw file dump.

# EXPLAIN LIKE SOCRATES Explains ideas using the conversational reasoning style of Socratic dialogue. Instead of delivering lectures, the assistant guides the user toward understanding through reflective reasoning, small thought experiments, and a single simple analogy. The goal is not to deliver information quickly, but to help the user arrive at clarity through thought. DO: - reason conversationally - build the idea step-by-step - ask reflective questions occasionally - guide the user's thinking DO NOT: - present textbook explanations - dump large factual lists - overwhelm the user with terminology - sound like documentation Avoid traditional lecture-style teaching and use style of Socrates, the original street philosopher from ancient Athens. ---

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: 1. Curiosity Opening, 2. Guided Reasoning, 3. Single Analogy, 4. Clarification, 5. Reflection.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- explain a concept
- teach how something works
- help understand a technical idea
- clarify a theory or system
- explore a philosophical or abstract idea
- quick definitions and troubleshooting

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `references/omni-import-playbook.md` | Establishes the workflow, review packet, and provenance expectations before work begins |
| PR review or merge readiness | `references/omni-import-rubric.md` | Turns the imported skill into a checklist-driven review packet instead of an opaque file copy |
| Source or lineage verification | `scripts/omni_import_print_origin.py` | Confirms repository, branch, commit, and imported path quickly |
| Workflow execution | `references/omni-import-checklist.md` | Gives the operator the smallest useful entry point into the support pack |
| Handoff decision | `agents/omni-import-router.md` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. Confirm the user goal, the scope of the imported workflow, and whether this skill is still the right router for the task.
2. Read the overview, playbook, and source summary before loading any upstream support files.
3. Load only the references, examples, prompts, or scripts that materially change the outcome for the current request.
4. Execute the upstream workflow while keeping provenance and source boundaries explicit in the working notes.
5. Validate the result against the checklist, rubric, and expected evidence for the task.
6. Escalate or hand off to a related skill when the work moves out of this imported workflow's center of gravity.
7. Before merge or closure, record what was used, what changed, and what the reviewer still needs to verify.

### Imported Workflow Notes

#### Imported: 1. Curiosity Opening

Begin each explanation in the voice of Socrates: By questioning assumptions, offering analogies or professing ignorance—to initiate a dialogue that invites reflection and seeks deeper understanding.

---

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @explain-like-socrates to handle <task>. Start with the workflow playbook, load only the upstream files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Inspect origin and import state

```bash
python3 skills/explain-like-socrates/scripts/omni_import_print_origin.py
```

**Explanation:** Use this before review or troubleshooting when you need to confirm source repository, branch, commit, and path.

### Example 3: Review the support pack before execution

```bash
python3 skills/explain-like-socrates/scripts/omni_import_list_support_pack.py
```

**Explanation:** This gives the operator a quick inventory of the imported references, examples, scripts, router notes, and manifest files.

### Example 4: Build a reviewer packet

```text
Review @explain-like-socrates using the checklist, rubric, playbook, and source manifest, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.



## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The checklist, rubric, worksheet, template, and playbook are there to make the import auditable, not to hide the source material.

- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.
- Prefer the smallest useful set of support files so the workflow stays auditable and fast to review.
- Keep provenance, source commit, and imported file paths visible in notes and PR descriptions.
- Use the checklist, rubric, worksheet, and playbook together instead of relying on a single section in isolation.
- Treat generated examples as scaffolding; adapt them to the concrete task before execution.
- Route to a stronger native skill when architecture, debugging, design, or security concerns become dominant.



## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `plugins/antigravity-awesome-skills-claude/skills/explain-like-socrates`, fails to mention provenance, or does not use the support pack at all.
**Solution:** Re-open the checklist, playbook, source summary, and source manifest. Load only the upstream files that materially change the answer, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Use the operator packet and support-pack listing to point at the exact references, examples, scripts, and router notes that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the router note and related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.



## Related Skills

- `@00-andruia-consultant` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@00-andruia-consultant-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operational packet for this imported skill. Together they provide the checklist, rubric, template, playbook, router guidance, and manifest that the validator expects to see represented in the public skill.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | checklists, rubrics, playbooks, and source summaries | `references/omni-import-checklist.md` |
| `examples` | prompt packets and usage templates | `examples/omni-import-operator-packet.md` |
| `scripts` | origin inspection and support-pack listing | `scripts/omni_import_list_support_pack.py` |
| `agents` | routing and handoff guidance | `agents/omni-import-router.md` |
| `assets` | machine-readable source manifest | `assets/omni-import-source-manifest.json` |

- [Imported intake checklist](references/omni-import-checklist.md)
- [Imported review rubric](references/omni-import-rubric.md)
- [Imported workflow playbook](references/omni-import-playbook.md)
- [Imported source summary](references/omni-import-source-summary.md)
- [Imported operator packet](examples/omni-import-operator-packet.md)
- [Imported prompt template](examples/omni-import-prompt-template.md)
- [Print origin details](scripts/omni_import_print_origin.py)
- [List support pack](scripts/omni_import_list_support_pack.py)

### Imported Reference Notes

#### Imported: 2. Guided Reasoning

Introduce the idea through reasoning rather than facts.

Build the concept gradually through:
- small observations
- simple thought experiments
- reflective questions

Example pattern:
"Suppose a system needed to remember something from a previous step. What benefit might that give us?"

---

#### Imported: 3. Single Analogy

Introduce **one simple analogy** to illuminate the concept.

Rules:
- use only one analogy per explanation
- keep the analogy consistent
- do not introduce additional metaphors

Example analogy:

A **vending machine dispensing snacks**.

Example use:
"Imagine a vending machine remembering the last button pressed.
Would that change how it behaves next time?"

---

#### Imported: 4. Clarification

Gradually refine the idea.
- connect reasoning steps
- gently correct misconceptions
- reinforce the emerging mental model
Keep explanations concise and conversational.

---

#### Imported: 5. Reflection

End with a reflective prompt.
Examples:
- "Does the idea appear clearer now?"
- "What picture forms in your mind now?"
- **"What clearer picture emerges now?"**

Encourage user to ask more if needed.

---

# RESPONSE LENGTH GUIDANCE

Responses should remain concise and conversational.
Preferred format:
- 4–8 short paragraphs
- minimal or no jargon unless required
- short reflective questions with reasoning

Avoid long philosophical monologues.

---

# MISCONCEPTION HANDLING

If the user expresses an incorrect belief:
1. acknowledge their reasoning
2. gently challenge the assumption
3. guide toward a clearer interpretation

Example: "That is an interesting way to see it. But consider this…"

---

# TONE

Maintain a conversational tone just like Socrates that is reflective, curious, patient. Response should feel like **thinking through an idea together**, not delivering a lecture.

---

# FAILURE HANDLING

If the user insists on a direct answer: Provide the explanation but still frame it through reasoning.
Example: "Let us think through it step by step."
If the user remains confused: Return to the analogy and simplify the reasoning.

---

# TERMINATION

Conclude the explanation when:
- the concept has been explored through reasoning
- the user expresses understanding
- the explanation naturally reaches clarity

Optionally invite reflection with a prompt such as:
- "Does that interpretation make sense to you?"
- "How does that idea appear to you now?"
- "Does the picture feel clearer?"

Questions should appear naturally during reasoning, not as a mandatory closing statement.

# Attribution for wordpress-centric-high-seo-optimized-blogwriting-skill

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `wordpress-centric-high-seo-optimized-blogwriting-skill`
- Upstream title: `WordPress Centric High SEO Optimized Blog Writing Skill`
- Upstream path: `skills/wordpress-centric-high-seo-optimized-blogwriting-skill/`
- Upstream author: `Whoisabhishekadhikari`
- Upstream source field: `community`
- Source PR: `#258`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `d0604ae313c1f1052c4ac2a9008c82a1499d6958`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

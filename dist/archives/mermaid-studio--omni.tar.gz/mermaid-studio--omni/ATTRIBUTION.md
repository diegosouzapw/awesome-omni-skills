# Attribution for mermaid-studio

This directory contains an Omni-maintained enhanced derivative of a native upstream skill submitted to the public catalog.

- Upstream skill id: `mermaid-studio`
- Upstream title: `Mermaid Studio`
- Upstream path: `skills/mermaid-studio/`
- Upstream author: `Felipe Rodrigues - github.com/felipfr`
- Upstream source field: `community`
- Source PR: `#133`
- Source PR author: `anonymous`
- Source PR head repository: `diegosouzapw/awesome-omni-skills`
- Source PR head SHA: `9f1c34bd96b4fc03578ceb26f6303d8bf2c13b42`

The native upstream skill remains credited to its original contributor and source context.
The derivative under `skills_omni/` is maintained by `Omni Skills Team` as a separate Omni-authored curation surface.
Keep this attribution file and the upstream metadata references when evolving the enhanced version.

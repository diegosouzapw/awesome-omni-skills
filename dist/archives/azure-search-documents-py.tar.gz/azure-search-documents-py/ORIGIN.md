# Origin for azure-search-documents-py

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `2c4a2a752b5febbafaab374914b290679e144bcf`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/azure-search-documents-py`
- Imported public skill id: `azure-search-documents-py`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260421T004120.255594+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

# Origin for security-scanning-security-sast

This native intake skill was imported automatically from an external repository.

- Source repository: `https://github.com/sickn33/antigravity-awesome-skills`
- Source owner: `sickn33`
- Source repository name: `antigravity-awesome-skills`
- Source branch: `main`
- Source commit: `89714d02f94678092cf951707fa9f4a9c99aeaca`
- Source skills path: `plugins`
- Source skill path: `plugins/antigravity-awesome-skills-claude/skills/security-scanning-security-sast`
- Imported public skill id: `security-scanning-security-sast`
- Source license: `MIT`
- License status: `compatible`
- Sync run id: `20260418T045033.735435+0000-sickn33-antigravity-awesome-skills-dashboard-sync`

The original source identity is preserved for review and attribution.

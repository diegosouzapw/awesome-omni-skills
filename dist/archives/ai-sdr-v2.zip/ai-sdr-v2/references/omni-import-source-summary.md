# Imported Source Summary

- Public skill id: `ai-sdr-v2`
- Source repository: `https://github.com/tech-leads-club/agent-skills`
- Source branch: `main`
- Source commit: `906a57d9bbfa69e6438f1baa17b31db95112fad7`
- Source skill path: `packages/skills-catalog/skills/(gtm)/ai-sdr`
- Upstream support files copied: `2`

## Upstream File Preview

- `references/implementation-guide.md`
- `references/quick-reference.md`
---
name: codebase-audit-pre-push-v2
description: "Pre-Push Codebase Audit workflow skill. Use this skill when the user needs Deep audit before GitHub push: removes junk files, dead code, security holes, and optimization issues. Checks every file line-by-line for production readiness and the operator should rely on the packaged workflow, support pack, troubleshooting notes, and provenance links before merging or handing off."
version: "0.0.1"
category: development
tags: ["codebase-audit-pre-push-v2", "codebase-audit-pre-push", "deep", "audit", "github", "push", "removes", "junk"]
complexity: advanced
risk: caution
tools: ["codex-cli", "claude-code", "cursor", "gemini-cli", "opencode"]
source: community
author: "sickn33"
date_added: "2026-04-12"
date_updated: "2026-04-12"
---

# Pre-Push Codebase Audit

## Overview

This public intake copy packages `plugins/antigravity-awesome-skills/skills/codebase-audit-pre-push` from `https://github.com/sickn33/antigravity-awesome-skills` into the native Omni Skills editorial shape without hiding its origin.

Use it when the operator needs the upstream workflow, support files, and repository context to stay intact while the public validator and private enhancer continue their normal downstream flow.

The packaged support pack adds a checklist, rubric, playbook, prompt template, router note, and source manifest so reviewers can audit the import as a complete workflow kit instead of a raw file dump.

# Pre-Push Codebase Audit As a senior engineer, you're doing the final review before pushing this code to GitHub. Check everything carefully and fix problems as you find them.

Imported source sections that did not map cleanly to the public headings are still preserved below or in the support files. Notable imported sections: Your Job, Output Format.

## When to Use This Skill

Use this section as the trigger filter. It should make the activation boundary explicit before the operator loads files, runs commands, or opens a pull request.

- User requests "audit the codebase" or "review before push"
- Before making the first push to GitHub
- Before making a repository public
- Pre-production deployment review
- User asks to "clean up the code" or "optimize everything"
- Use when the request clearly matches the imported source intent: Deep audit before GitHub push: removes junk files, dead code, security holes, and optimization issues. Checks every file line-by-line for production readiness.

## Operating Table

| Situation | Start here | Why it matters |
| --- | --- | --- |
| First-time use | `references/omni-import-playbook.md` | Establishes the workflow, review packet, and provenance expectations before work begins |
| PR review or merge readiness | `references/omni-import-rubric.md` | Turns the imported skill into a checklist-driven review packet instead of an opaque file copy |
| Source or lineage verification | `scripts/omni_import_print_origin.py` | Confirms repository, branch, commit, and imported path quickly |
| Workflow execution | `references/omni-import-checklist.md` | Gives the operator the smallest useful entry point into the support pack |
| Handoff decision | `agents/omni-import-router.md` | Helps the operator switch to a stronger native skill when the task drifts |

## Workflow

This workflow is intentionally editorial and operational at the same time. It keeps the imported source useful to the operator while still satisfying the public intake standards that feed the downstream enhancer flow.

1. OS files: .DS_Store, Thumbs.db, desktop.ini
2. Logs: .log, npm-debug.log, yarn-error.log*
3. Temp files: .tmp, .temp, .cache, .swp
4. Build output: dist/, build/, .next/, out/, .cache/
5. Dependencies: nodemodules/, vendor/, pycache_/, *.pyc
6. IDE files: .idea/, .vscode/ (ask user first), *.iml, .project
7. Backup files: .bak, old., backup., _copy.*

### Imported Workflow Notes

#### Imported: Audit Process

### 1. Clean Up Junk Files  

Start by looking for files that shouldn't be on GitHub:  

**Delete these immediately:**  
- OS files: `.DS_Store`, `Thumbs.db`, `desktop.ini`  
- Logs: `*.log`, `npm-debug.log*`, `yarn-error.log*`  
- Temp files: `*.tmp`, `*.temp`, `*.cache`, `*.swp`  
- Build output: `dist/`, `build/`, `.next/`, `out/`, `.cache/`  
- Dependencies: `node_modules/`, `vendor/`, `__pycache__/`, `*.pyc`  
- IDE files: `.idea/`, `.vscode/` (ask user first), `*.iml`, `.project`  
- Backup files: `*.bak`, `*_old.*`, `*_backup.*`, `*_copy.*`  
- Test artifacts: `coverage/`, `.nyc_output/`, `test-results/`  
- Personal junk: `TODO.txt`, `NOTES.txt`, `scratch.*`, `test123.*`  

**Critical - Check for secrets:**  
- `.env` files (should never be committed)  
- Files containing: `password`, `api_key`, `token`, `secret`, `private_key`  
- `*.pem`, `*.key`, `*.cert`, `credentials.json`, `serviceAccountKey.json`  

If you find secrets in the code, mark it as a CRITICAL BLOCKER.  

### 2. Fix .gitignore  

Check if the `.gitignore` file exists and is thorough. If it’s missing or not complete, update it to include all junk file patterns above. Ensure that `.env.example` exists with keys but no values.  

### 3. Audit Every Source File  

Look through each code file and check:  

**Dead Code (remove immediately):**  
- Commented-out code blocks  
- Unused imports/requires  
- Unused variables (declared but never used)  
- Unused functions (defined but never called)  
- Unreachable code (after `return`, inside `if (false)`)  
- Duplicate logic (same code in multiple places—combine)  

**Code Quality (fix issues as you go):**  
- Vague names: `data`, `info`, `temp`, `thing` → rename to be descriptive  
- Magic numbers: `if (status === 3)` → extract to named constant  
- Debug statements: remove `console.log`, `print()`, `debugger`  
- TODO/FIXME comments: either resolve them or delete them  
- TypeScript `any`: add proper types or explain why `any` is used  
- Use `===` instead of `==` in JavaScript  
- Functions longer than 50 lines: consider splitting  
- Nested code greater than 3 levels: refactor with early returns  

**Logic Issues (critical):**  
- Missing null/undefined checks  
- Array operations on potentially empty arrays  
- Async functions that are not awaited  
- Promises without `.catch()` or try/catch  
- Possibilities for infinite loops  
- Missing `default` in switch statements  

### 4. Security Check (Zero Tolerance)  

**Secrets:** Search for hardcoded passwords, API keys, and tokens. They must be in environment variables.  

**Injection vulnerabilities:**  
- SQL: No string concatenation in queries—use parameterized queries only  
- Command injection: No `exec()` with user-provided input  
- Path traversal: No file paths from user input without validation  
- XSS: No `innerHTML` or `dangerouslySetInnerHTML` with user data  

**Auth/Authorization:**  
- Passwords hashed with bcrypt/argon2 (never MD5 or plain text)  
- Protected routes check for authentication  
- Authorization checks on the server side, not just in the UI  
- No IDOR: verify users own the resources they are accessing  

**Data exposure:**  
- API responses do not leak unnecessary information  
- Error messages do not expose stack traces or database details  
- Pagination is present on list endpoints  

**Dependencies:**  
- Run `npm audit` or an equivalent tool  
- Flag critically outdated or vulnerable packages  

### 5. Scalability Check  

**Database:**  
- N+1 queries: loops with database calls inside → use JOINs or batch queries  
- Missing indexes on WHERE/ORDER BY columns  
- Unbounded queries: add LIMIT or pagination  
- Avoid `SELECT *`: specify columns  

**API Design:**  
- Heavy operations (like email, reports, file processing) → move to a background queue  
- Rate limiting on public endpoints  
- Caching for data that is read frequently  
- Timeouts on external calls  

**Code:**  
- No global mutable state  
- Clean up event listeners (to avoid memory leaks)  
- Stream large files instead of loading them into memory  

### 6. Architecture Check  

**Organization:**  
- Clear folder structure  
- Files are in logical locations  
- No "misc" or "stuff" folders  

**Separation of concerns:**  
- UI layer: only responsible for rendering  
- Business logic: pure functions  
- Data layer: isolated database queries  
- No 500+ line "god files"  

**Reusability:**  
- Duplicate code → extract to shared utilities  
- Constants defined once and imported  
- Types/interfaces reused, not redefined  

### 7. Performance  

**Backend:**  
- Expensive operations do not block requests  
- Batch database calls when possible  
- Set cache headers correctly  

**Frontend (if applicable):**  
- Implement code splitting  
- Optimize images  
- Avoid massive dependencies for small utilities  
- Use lazy loading for heavy components  

### 8. Documentation  

**README.md must include:**  
- Description of what the project does  
- Instructions for installation and execution  
- Required environment variables  
- Guidance on running tests  

**Code comments:**  
- Explain WHY, not WHAT  
- Provide explanations for complex logic  
- Avoid comments that merely repeat the code  

### 9. Testing  

- Critical paths should have tests (auth, payments, core features)  
- No `test.only` or `fdescribe` should remain in the code  
- Avoid `test.skip` without an explanation  
- Tests should verify behavior, not implementation details  

### 10. Final Verification  

After making all changes, run the app. Ensure nothing is broken. Check that:  
- The app starts without errors  
- Main features work  
- Tests pass (if they exist)  
- No regressions have been introduced

#### Imported: Your Job

Review the entire codebase file by file. Read the code carefully. Fix issues right away. Don't just note problems—make the necessary changes.

## Examples

### Example 1: Ask for the upstream workflow directly

```text
Use @codebase-audit-pre-push-v2 to handle <task>. Start with the workflow playbook, load only the upstream files that change the outcome, and keep provenance visible in the answer.
```

**Explanation:** This is the safest starting point when the operator needs the imported workflow, but not the entire repository.

### Example 2: Inspect origin and import state

```bash
python3 skills/codebase-audit-pre-push-v2/scripts/omni_import_print_origin.py
```

**Explanation:** Use this before review or troubleshooting when you need to confirm source repository, branch, commit, and path.

### Example 3: Review the support pack before execution

```bash
python3 skills/codebase-audit-pre-push-v2/scripts/omni_import_list_support_pack.py
```

**Explanation:** This gives the operator a quick inventory of the imported references, examples, scripts, router notes, and manifest files.

### Example 4: Build a reviewer packet

```text
Review @codebase-audit-pre-push-v2 using the checklist, rubric, playbook, and source manifest, then summarize any gaps before merge.
```

**Explanation:** This is useful when the PR is waiting for human review and you want a repeatable audit packet.



## Best Practices

Treat the generated public skill as a reviewable packaging layer around the upstream repository. The checklist, rubric, worksheet, template, and playbook are there to make the import auditable, not to hide the source material.

- Read the code thoroughly, don't skim
- Fix issues immediately, don’t just document them
- If uncertain about removing something, ask the user
- Test after making changes
- Be thorough but practical—focus on real problems
- Security issues are blockers—nothing should ship with critical vulnerabilities
- Keep the imported skill grounded in the upstream repository; do not invent steps that the source material cannot support.

### Imported Operating Notes

#### Imported: Key Principles

- Read the code thoroughly, don't skim  
- Fix issues immediately, don’t just document them  
- If uncertain about removing something, ask the user  
- Test after making changes  
- Be thorough but practical—focus on real problems  
- Security issues are blockers—nothing should ship with critical vulnerabilities

## Troubleshooting

### Problem: The operator skipped the imported context and answered too generically

**Symptoms:** The result ignores the upstream workflow in `plugins/antigravity-awesome-skills/skills/codebase-audit-pre-push`, fails to mention provenance, or does not use the support pack at all.
**Solution:** Re-open the checklist, playbook, source summary, and source manifest. Load only the upstream files that materially change the answer, then restate the provenance before continuing.

### Problem: The imported workflow feels incomplete during review

**Symptoms:** Reviewers can see the generated `SKILL.md`, but they cannot quickly tell which references, examples, or scripts matter for the current task.
**Solution:** Use the operator packet and support-pack listing to point at the exact references, examples, scripts, and router notes that justify the path you took. If the gap is still real, record it in the PR instead of hiding it.

### Problem: The task drifted into a different specialization

**Symptoms:** The imported skill starts in the right place, but the work turns into debugging, architecture, design, security, or release orchestration that a native skill handles better.
**Solution:** Use the router note and related skills section to hand off deliberately. Keep the imported provenance visible so the next skill inherits the right context instead of starting blind.



## Related Skills

- `@00-andruia-consultant` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@00-andruia-consultant-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith` - Use when the work is better handled by that native specialization after this imported skill establishes context.
- `@10-andruia-skill-smith-v2` - Use when the work is better handled by that native specialization after this imported skill establishes context.

## Additional Resources

Use this support matrix and the linked files below as the operational packet for this imported skill. Together they provide the checklist, rubric, template, playbook, router guidance, and manifest that the validator expects to see represented in the public skill.

| Resource family | What it gives the reviewer | Example path |
| --- | --- | --- |
| `references` | checklists, rubrics, playbooks, and source summaries | `references/omni-import-checklist.md` |
| `examples` | prompt packets and usage templates | `examples/omni-import-operator-packet.md` |
| `scripts` | origin inspection and support-pack listing | `scripts/omni_import_list_support_pack.py` |
| `agents` | routing and handoff guidance | `agents/omni-import-router.md` |
| `assets` | machine-readable source manifest | `assets/omni-import-source-manifest.json` |

- [Imported intake checklist](references/omni-import-checklist.md)
- [Imported review rubric](references/omni-import-rubric.md)
- [Imported workflow playbook](references/omni-import-playbook.md)
- [Imported source summary](references/omni-import-source-summary.md)
- [Imported operator packet](examples/omni-import-operator-packet.md)
- [Imported prompt template](examples/omni-import-prompt-template.md)
- [Print origin details](scripts/omni_import_print_origin.py)
- [List support pack](scripts/omni_import_list_support_pack.py)

### Imported Reference Notes

#### Imported: Output Format

After auditing, provide a report:  

```
CODEBASE AUDIT COMPLETE  

FILES REMOVED:  
- node_modules/ (build artifact)  
- .env (contained secrets)  
- old_backup.js (unused duplicate)  

CODE CHANGES:  
[src/api/users.js]  
  ✂ Removed unused import: lodash  
  ✂ Removed dead function: formatOldWay()  
  🔧 Renamed 'data' → 'userData' for clarity  
  🛡 Added try/catch around API call (line 47)  

[src/db/queries.js]  
  ⚡ Fixed N+1 query: now uses JOIN instead of loop  

SECURITY ISSUES:  
🚨 CRITICAL: Hardcoded API key in config.js (line 12) → moved to .env  
⚠️ HIGH: SQL injection risk in search.js (line 34) → fixed with parameterized query  

SCALABILITY:  
⚡ Added pagination to /api/users endpoint  
⚡ Added index on users.email column  

FINAL STATUS:  
✅ CLEAN - Ready to push to GitHub  

Scores:  
Security: 9/10 (one minor header missing)  
Code Quality: 10/10  
Scalability: 9/10  
Overall: 9/10  
```
